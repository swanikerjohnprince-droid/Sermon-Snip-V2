(() => {
"use strict";
const TOKEN = document.querySelector('meta[name=token]').content;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const WHISPER_MODELS = [["large-v3", "large-v3 (best)"], ["distil-large-v3", "distil-large-v3 (fast)"], ["medium", "medium"], ["small", "small"], ["base", "base"], ["tiny", "tiny"]];
const AUTOSUBS_MODELS = [["large-v3-turbo", "large-v3-turbo (fast)"], ["large-v3", "large-v3 (best)"], ["medium", "medium"], ["small", "small"], ["base", "base"], ["tiny", "tiny"]];
const STEPS = [[1, "Source"], [2, "Moments"], [3, "Reframe"], [4, "Captions"], [5, "Export"]];

let S = null, view = 1, lastRev = -1, prevJob = null, initialised = false, offline = false;
const ui = { sort: "score", filter: "all", preset: "ss:bold_pop", density: "standard", lines: 1, colorTouched: false, dismissedError: null, collapsed: false, gpuShown: null, gpuReport: null, requested: new Set(), gen: -1, thumbsAsked: false, vgpuAsked: false, cpTimer: null, cpClip: null };

// ------------------------------------------------------------------ helpers
const esc = (t) => String(t ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = (s) => { s = Math.max(0, Math.round(s)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return `${h}:${String(m).padStart(2, "0")}:${String(x).padStart(2, "0")}`; };
const mins = (s) => s >= 3600 ? `${(s / 3600).toFixed(1)} h` : `${Math.round(s / 60)} min`;
const media = (rel) => `/media/${rel.split("/").map(encodeURIComponent).join("/")}?t=${TOKEN}`;
const tpl = (html) => { const t = document.createElement("template"); t.innerHTML = html.trim(); return t.content.firstElementChild; };

async function api(path, body) {
  try {
    const r = await fetch(`${path}?t=${TOKEN}`, { method: "POST", headers: { "Content-Type": "application/json", "X-Token": TOKEN }, body: JSON.stringify(body || {}) });
    const j = await r.json();
    if (j.ok === false && j.error) toast(j.error, "bad");
    return j;
  } catch (e) { toast("Lost contact with Sermon-Snip.", "bad"); return { ok: false }; }
}

function toast(text, kind = "") {
  const t = tpl(`<div class="toast ${kind}"></div>`); t.textContent = text; $("#toasts").appendChild(t);
  setTimeout(() => t.remove(), kind === "bad" ? 9000 : 5000);
}

/** Keyed list reconciler: existing elements are updated in place, so playing <video> elements survive. */
function sync(container, items, key, create, update) {
  const existing = new Map($$(":scope > [data-key]", container).map((e) => [e.dataset.key, e]));
  items.forEach((it, i) => {
    const k = String(key(it));
    let el = existing.get(k);
    if (!el) { el = create(it); el.dataset.key = k; } else existing.delete(k);
    update(el, it);
    if (container.children[i] !== el) container.insertBefore(el, container.children[i] || null);
  });
  existing.forEach((el) => el.remove());
}

function modal(title, body, buttons) {
  $("#modal-title").textContent = title; $("#modal-body").textContent = body;
  const box = $("#modal-actions"); box.innerHTML = "";
  buttons.forEach(([label, cls, fn]) => { const b = tpl(`<button type="button" class="btn ${cls || ""}"></button>`); b.textContent = label; b.onclick = () => { $("#modal").close(); fn && fn(); }; box.appendChild(b); });
  if (!$("#modal").open) $("#modal").showModal();
}

const jobRunning = () => S && S.job.status === "running";
const selected = () => S.moments.filter((m) => m.selected);
const can = () => ({
  1: true,
  2: !!S.source && S.selection.audio.length > 0,
  3: S.moments.length > 0 && S.selection.video.length > 0,
  4: S.moments.some((m) => m.reframe.status === "done"),
  // the export step also opens while an export is running or has produced clips (Export all starts from nothing)
  5: S.moments.some((m) => m.reframe.status === "done" || m.final.status !== "idle") || (S.job.status === "running" && ["export_all", "export"].includes(S.job.kind)),
});

// ------------------------------------------------------------------ polling
async function poll() {
  try {
    const r = await fetch(`/api/state?t=${TOKEN}`, { headers: { "X-Token": TOKEN } });
    if (!r.ok) throw new Error(r.status);
    S = await r.json();
    if (offline) { offline = false; $("#banner").classList.add("hidden"); }
    if (S.rev !== lastRev) { lastRev = S.rev; render(); }
  } catch (e) {
    if (!offline) { offline = true; showBanner("Sermon-Snip has stopped (or the connection was lost). Re-run it to continue."); }
  }
  setTimeout(poll, jobRunning() ? 450 : 900);
}

function showBanner(text) { $("#banner-msg").textContent = text; $("#banner").classList.remove("hidden"); }

// ------------------------------------------------------------------ render
function render() {
  if (!initialised) { initialised = true; view = S.moments.length ? 2 : 1; initControls(); }
  renderTop(); renderJob(); renderStep1(); renderStep2(); renderStep3(); renderStep4(); renderStep5(); renderGpu();
  if (!can()[view]) view = 1;
  showView();
}

function showView() {
  STEPS.forEach(([n]) => $(`#step${n}`).classList.toggle("hidden", n !== view));
  $$(".pill").forEach((p) => p.classList.toggle("active", Number(p.dataset.n) === view));
}

function go(n) {
  const c = can();
  if (!c[n]) {
    toast({ 2: "Choose a timeline or file, and at least one audio track, first.", 3: "Find moments and make sure a video track is selected first.", 4: "Reframe at least one clip first (or press Export all).", 5: "Reframe at least one clip first (or press Export all)." }[n], "bad");
    return;
  }
  view = n; showView(); window.scrollTo({ top: 0, behavior: "smooth" });
}

function renderTop() {
  const c = can();
  const done = { 1: c[2], 2: selected().length > 0, 3: c[4], 4: S.moments.some((m) => m.captions.status === "done"), 5: S.moments.some((m) => m.final.status === "done") };
  const nav = $("#stepper");
  if (!nav.children.length) STEPS.forEach(([n, label]) => nav.appendChild(tpl(`<div class="pill" data-n="${n}"><span class="n">${n}</span><b>${label}</b></div>`)));
  $$(".pill", nav).forEach((p) => {
    const n = Number(p.dataset.n);
    p.classList.toggle("locked", !c[n]); p.classList.toggle("done", !!done[n] && n !== view);
    $(".n", p).textContent = done[n] && n !== view ? "✓" : n;
  });
  const tools = $("#tools"); tools.innerHTML = "";
  [["FFmpeg", S.tools.ffmpeg, null], ["verthor", S.tools.verthor, "verthor_path"], ["AutoSubs", S.tools.autosubs, "autosubs_path"]].forEach(([name, ok, key]) => {
    const t = tpl(`<span class="tool ${ok ? "ok" : "miss"}" title="${ok ? name + " found" : name + " not found. Click to locate it."}"><i></i>${name}</span>`);
    if (!ok) t.onclick = () => key ? api("/api/tools/locate", { tool: key }) : toast("Install FFmpeg with:  winget install Gyan.FFmpeg  then restart Sermon-Snip.", "bad");
    tools.appendChild(t);
  });
}

function renderJob() {
  const j = S.job, bar = $("#jobbar");
  bar.classList.toggle("hidden", j.status !== "running");
  if (j.status === "running") {
    $("#job-msg").textContent = j.message || "Working…";
    $(".bar", bar).classList.toggle("indeterminate", j.fraction == null);
    if (j.fraction != null) $("#job-bar").style.width = `${Math.max(3, Math.round(j.fraction * 100))}%`;
  }
  if (prevJob && prevJob.status === "running" && j.status !== "running") {
    if (j.status === "done" && j.message) toast(j.message, "ok");
    if (j.status === "cancelled") toast("Cancelled.");
  }
  if (j.status === "error" && j.error && ui.dismissedError !== j.error) showBanner(j.error);
  else if (j.status !== "error" && !offline) $("#banner").classList.add("hidden");
  prevJob = { status: j.status, kind: j.kind };
  ["btn-analyze", "btn-rerank", "btn-reframe", "btn-export", "btn-cut", "btn-exportall"].forEach((id) => { const b = $("#" + id); if (b) b.dataset.busy = j.status === "running" ? "1" : ""; });
  updateEnabled();
}

function updateEnabled() {
  const busy = jobRunning(), c = can(), sel = selected();
  const set = (id, off) => { const b = $("#" + id); if (b) b.disabled = !!off; };
  set("btn-analyze", busy || !c[2]); set("btn-rerank", busy || !S.moments.length);
  set("to-2", !c[2]); set("to-3", busy || !sel.length || !S.selection.video.length); set("to-4", !c[4]);
  set("btn-reframe", busy || !sel.length || !S.selection.video.length);
  set("btn-export", busy || !sel.some((m) => m.reframe.status === "done"));
  set("btn-exportall", busy || !sel.length || !S.selection.video.length);
  set("btn-captions", busy || !sel.some((m) => m.reframe.status === "done"));
  set("btn-cap-preview", !sel.some((m) => m.reframe.status === "done"));
  set("btn-cut", busy || !sel.length || S.source?.kind !== "resolve");
  set("btn-import", !S.moments.some((m) => m.final.status === "done") || !(S.resolve.direct || S.resolve.scripts_installed || S.source?.kind === "resolve"));
}

// ------------------------------------------------------------------ step 1
function renderStep1() {
  const r = S.resolve, src = S.source, fromResolve = src?.kind === "resolve";
  $("#resolve-dot").className = "dot " + (fromResolve || r.direct ? "on" : (r.scripts_installed ? "warn" : ""));
  $("#resolve-status").textContent = r.direct ? "Connected directly to Resolve. " + (r.reason || "")
    : fromResolve ? `Timeline "${src.timeline}" received from Resolve ✓`
    : r.scripts_installed ? "Script installed. Now run SermonSnip inside Resolve." : "Not set up yet.";
  $('#how li[data-k=install]').classList.toggle("done", !!r.scripts_installed);
  $('#how li[data-k=export]').classList.toggle("done", fromResolve);
  $("#tracks-card").classList.toggle("hidden", !src);
  if (!src) return;
  $("#source-title").textContent = src.kind === "resolve" ? `Resolve timeline: ${src.timeline}` : `File: ${src.timeline}`;
  $("#listening").classList.toggle("hidden", !src.listening);
  const chips = [`${mins(src.duration)} long`, src.fps ? `${Number(src.fps).toFixed(src.fps % 1 ? 2 : 0)} fps` : null, src.width ? `${src.width}×${src.height}` : null, src.project ? `Project: ${src.project}` : null, src.resolve_version ? `Resolve ${src.resolve_version}` : null].filter(Boolean);
  $("#source-chips").innerHTML = chips.map((c) => `<span class="chip">${esc(c)}</span>`).join("");
  const w = $("#source-warn"); w.classList.toggle("hidden", !src.warnings.length); w.textContent = src.warnings.join(" ");
  ["audio", "video"].forEach((kind) => {
    const list = $(`#${kind}-tracks`), tracks = src.tracks.filter((t) => t.type === kind);
    if (!tracks.length) { list.innerHTML = `<p class="muted small">${kind === "video" ? "No video tracks. You can still find moments, but reframing needs video." : "No audio tracks found."}</p>`; return; }
    list.querySelectorAll("p").forEach((p) => p.remove());
    sync(list, tracks, (t) => `${t.type}${t.index}`,
      () => tpl(`<label class="track"><input type="checkbox"><div class="grow"><div class="t-name"></div><div class="t-sub"></div><div class="meter"><i></i></div><div class="t-flags"></div></div></label>`),
      (el, t) => {
        const on = S.selection[kind].includes(t.index), cb = $("input", el), dead = !t.usable || t.silent;
        el.classList.toggle("on", on); el.classList.toggle("off", dead); cb.checked = on; cb.disabled = dead; cb.dataset.kind = kind; cb.dataset.index = t.index;
        $(".t-name", el).textContent = `${kind === "audio" ? "A" : "V"}${t.index} · ${t.name}`;
        const bits = [`${t.usable}/${t.items} clips`, t.covered ? mins(t.covered) : null, t.files.join(", ") || null, !t.usable ? "nothing Sermon-Snip can read" : null, ...t.warnings.slice(0, 1)].filter(Boolean);
        $(".t-sub", el).textContent = bits.join(" · ");
        const meter = $(".meter", el); meter.classList.toggle("hidden", kind !== "audio" || t.level_db == null);
        meter.classList.toggle("silent", !!t.silent);
        $("i", meter).style.width = `${Math.max(4, Math.min(100, Math.round(((t.level_db ?? -60) + 60) / 60 * 100)))}%`;
        const flags = [];
        if (kind === "audio" && t.silent && t.level_db != null) flags.push(`<span class="chip bad">No sound</span>`);
        else if (kind === "audio" && t.level_db != null) flags.push(`<span class="chip">${Math.round(t.level_db)} dB average</span>`);
        if (kind === "audio" && (src.suggested || []).includes(t.index) && !t.silent) flags.push(`<span class="chip ok">Likely the speaker</span>`);
        $(".t-flags", el).innerHTML = flags.join("");
      });
  });
  const a = S.selection.audio.length, v = S.selection.video.length;
  $("#track-hint").textContent = !a ? "Choose at least one audio track." : `${a} audio and ${v} video track${v === 1 ? "" : "s"} selected.` + (!v ? " (Without video you can find moments but not reframe.)" : "");
}

// ------------------------------------------------------------------ step 2
function fillModels() {
  const list = $("#s-engine").value === "autosubs" ? AUTOSUBS_MODELS : WHISPER_MODELS, cur = $("#s-model").value;
  $("#s-model").innerHTML = list.map(([v, l]) => `<option value="${v}">${l}</option>`).join("");
  $("#s-model").value = list.some(([v]) => v === cur) ? cur : list[0][0];
}

function initControls() {
  const s = S.settings;
  $("#s-engine").value = s.engine; fillModels(); $("#s-model").value = s.model; $("#s-device").value = s.device; $("#s-language").value = s.language;
  $("#s-target").value = s.target; $("#s-target-val").textContent = s.target + "s"; $("#s-vocab").value = s.vocabulary || "";
  $("#s-gemini").checked = !!s.gemini; $("#g-model").value = s.gemini_model === S.gemini.default_model ? "" : s.gemini_model; $("#g-weight").value = Math.round(s.gemini_weight * 100); $("#g-weight-val").textContent = Math.round(s.gemini_weight * 100) + "%";
  $("#g-weight").oninput = () => ($("#g-weight-val").textContent = $("#g-weight").value + "%");
  $("#s-engine").onchange = fillModels;
  $("#s-target").oninput = () => ($("#s-target-val").textContent = $("#s-target").value + "s");
  $("#r-preset").innerHTML = S.preset_names.map((p) => `<option>${p}</option>`).join("");
  const r = S.reframe_opts; $("#r-preset").value = r.preset; $("#r-smart").checked = r.smart; $("#r-fast").checked = r.fast; $("#r-audio").value = r.audio; $("#r-aspect").value = r.aspect;
  const c = S.caption_opts;
  ui.preset = c.preset; ui.density = c.density; ui.lines = c.lines; ui.colorTouched = !!c.highlight;
  $("#c-words").value = c.max_words; $("#c-chars").value = c.max_chars; $("#c-case").value = c.text_case; $("#c-punct").checked = c.remove_punctuation;
  $("#c-size").value = Math.round(c.size * 100); $("#c-size-val").textContent = Math.round(c.size * 100) + "%"; $("#c-source").value = c.source; $("#c-burn").checked = c.burn;
  if (c.highlight) $("#c-color").value = "#" + c.highlight;
  $("#c-size").oninput = () => ($("#c-size-val").textContent = $("#c-size").value + "%");
  $("#c-color").oninput = () => { ui.colorTouched = true; schedulePreview(); };
  $$("#c-density button").forEach((b) => (b.onclick = () => { ui.density = b.dataset.d; renderStep4(); schedulePreview(); }));
  $$("#c-lines button").forEach((b) => (b.onclick = () => { ui.lines = Number(b.dataset.l); renderStep4(); schedulePreview(); }));
  $$("#p-filter button").forEach((b) => (b.onclick = () => { ui.filter = b.dataset.f; renderStep4(); }));
  ["c-words", "c-chars", "c-case", "c-punct", "c-size", "c-source", "c-burn"].forEach((id) => $("#" + id).addEventListener("change", schedulePreview));
  $$("#m-sort button").forEach((b) => (b.onclick = () => { ui.sort = b.dataset.sort; renderStep2(); }));
  const e = S.export_opts;
  $("#e-quality").innerHTML = Object.entries(S.quality).map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join(""); $("#e-quality").value = e.quality;
  $("#e-nvenc").value = e.nvenc; $("#e-srt").checked = e.sidecar_srt; $("#e-ass").checked = e.sidecar_ass;
}

const analysisSettings = () => ({ engine: $("#s-engine").value, device: $("#s-device").value, model: $("#s-model").value, language: $("#s-language").value, vocabulary: $("#s-vocab").value.trim(), target: Number($("#s-target").value),
  gemini: $("#s-gemini").checked, gemini_model: $("#g-model").value.trim() || S.gemini.default_model, gemini_weight: Number($("#g-weight").value) / 100 });

function renderStep2() {
  $("#analyze-hint").textContent = S.language && S.moments.length ? `Language detected: ${S.language}` : "";
  $("#g-state").textContent = S.gemini.has_key ? "(key saved)" : "(no key yet)"; $("#g-note").textContent = S.gemini.note || "";
  if (S.moments.length && !ui.collapsed) { $("#analysis-settings").open = false; ui.collapsed = true; }
  if (!S.moments.length) ui.collapsed = false;
  $("#m-toolbar").classList.toggle("hidden", !S.moments.length); $("#m-empty").classList.toggle("hidden", !!S.moments.length);
  $("#btn-cut").classList.toggle("hidden", S.source?.kind !== "resolve");
  $$("#m-sort button").forEach((b) => b.classList.toggle("on", b.dataset.sort === ui.sort));
  const sel = selected(); $("#m-count").textContent = `${sel.length} of ${S.moments.length} selected`;
  const cut = $("#cut-note"); cut.classList.toggle("hidden", S.cut.status === "idle"); cut.textContent = S.cut.message || "";
  if (ui.gen !== S.generation) { ui.gen = S.generation; ui.requested.clear(); }
  const items = [...S.moments].sort((a, b) => ui.sort === "time" ? a.start - b.start : b.score - a.score);
  sync($("#moments"), items, (m) => m.id, createMoment, updateMoment);
}

function createMoment(m) {
  const el = tpl(`<article class="moment"><div class="m-media"></div><div class="m-body">
    <div class="m-head"><div class="ring"><span></span></div><div class="m-meta"><div class="m-rank"></div><div class="m-time"></div></div>
    <label class="check" title="Use this moment"><input type="checkbox"><span></span></label></div>
    <h3 class="m-title"></h3><p class="m-text" title="Click to expand"></p><div class="ai hidden"></div><div class="chips"></div>
    <div class="row tight"><button class="link" data-act="adjust-toggle">Adjust start / end ✎</button></div>
    <div class="adjust"><div class="grp" data-edge="start"><span>Start</span><button data-adj="start:-5">−5s</button><button data-adj="start:-1">−1s</button><button data-adj="start:1">+1s</button><button data-adj="start:5">+5s</button></div>
    <div class="grp" data-edge="end"><span>End</span><button data-adj="end:-5">−5s</button><button data-adj="end:-1">−1s</button><button data-adj="end:1">+1s</button><button data-adj="end:5">+5s</button></div>
    <button data-adj="reset" class="reset">Reset</button></div></div></article>`);
  $("input", el).onchange = pushSelection;
  $(".m-text", el).onclick = (e) => e.currentTarget.classList.toggle("open");
  observer.observe($(".m-media", el));
  $(".m-media", el).dataset.id = m.id;
  return el;
}

const observer = new IntersectionObserver((entries) => entries.forEach((en) => {
  if (!en.isIntersecting) return;
  const id = Number(en.target.dataset.id), m = S && S.moments.find((x) => x.id === id);
  if (m && m.preview.status === "idle" && !ui.requested.has(`${id}.${m.ver}`)) { ui.requested.add(`${id}.${m.ver}`); api("/api/moments/preview", { id }); }
}), { rootMargin: "200px" });

function updateMoment(el, m) {
  el.classList.toggle("sel", m.selected);
  $(".ring", el).style.setProperty("--p", (m.score / 100).toFixed(3)); $(".ring span", el).textContent = Math.round(m.score);
  const adjusted = Math.abs(m.start - m.orig[0]) > 0.01 || Math.abs(m.end - m.orig[1]) > 0.01;      // judged by the edges, not by how many edits were made
  $(".m-rank", el).textContent = `#${m.id} · ${Math.round(m.duration)}s` + (adjusted ? " · adjusted" : "");
  $(".m-time", el).textContent = `${fmt(m.start)} → ${fmt(m.end)}`;
  $(".m-title", el).textContent = m.title; $(".m-text", el).textContent = m.text;
  const ai = $(".ai", el); ai.classList.toggle("hidden", m.ai_score == null); if (m.ai_score != null) ai.textContent = `Gemini ${Math.round(m.ai_score)}: ${m.ai_reason || ""}`;
  const chips = [`Delivery ${Math.round(m.audio_score * 100)}%`, `Message ${Math.round(m.text_score * 100)}%`, ...(m.signals || []).slice(0, 4)];
  $(".chips", el).innerHTML = chips.map((c, i) => `<span class="chip ${i < 2 ? "ok" : ""}">${esc(c)}</span>`).join("");
  const cb = $("input", el); if (cb.checked !== m.selected) cb.checked = m.selected; cb.dataset.id = m.id;
  el.dataset.id = m.id;
  setMedia($(".m-media", el), m.preview, m.id);
}

/** Render a preview slot. Only touches the DOM when the state or file changes. */
function setMedia(box, p, id, opts = {}) {
  const key = `${p.status}|${p.file || ""}`;
  if (box.dataset.state === key) return;
  box.dataset.state = key;
  if (p.status === "ready") {
    const tag = p.kind === "audio" ? "audio" : "video";
    const node = tpl(`<${tag} controls preload="metadata" playsinline ${opts.muted ? "muted" : ""}></${tag}>`);
    node.src = media(p.file); box.replaceChildren(node); return;
  }
  if (p.status === "error") { box.replaceChildren(tpl(`<div class="ph"><span>Preview failed</span><span class="small"></span><button type="button" title="Try again">↻</button></div>`)); $(".small", box).textContent = p.error || ""; $("button", box).onclick = () => api("/api/moments/preview", { id }); return; }
  if (p.status === "queued" || p.status === "running") { box.replaceChildren(tpl(`<div class="ph"><span class="spinner"></span><span>Preparing preview…</span></div>`)); return; }
  box.replaceChildren(tpl(`<div class="ph"><button type="button" title="Load preview">▶</button><span>Preview</span></div>`));
  $("button", box).onclick = () => api("/api/moments/preview", { id });
}

function pushSelection() {
  const ids = $$("#moments input[type=checkbox]").filter((c) => c.checked).map((c) => Number(c.dataset.id));
  $$("#moments .moment").forEach((el) => el.classList.toggle("sel", $("input", el).checked));
  $("#m-count").textContent = `${ids.length} of ${S.moments.length} selected`;
  api("/api/moments/select", { ids });
}

// ------------------------------------------------------------------ step 3
function reframeOptions() {
  return { smart: $("#r-smart").checked, preset: $("#r-preset").value, fast: $("#r-fast").checked, audio: $("#r-audio").value, aspect: $("#r-aspect").value };
}

function renderStep3() {
  const sel = selected().sort((a, b) => a.start - b.start);
  const orig = $("#r-aspect").value === "original";
  $("#r-smart").disabled = orig; $("#r-preset").disabled = orig; $("#r-fast").disabled = orig;
  $("#r-tool").textContent = S.tools.verthor ? "(verthor)" : "(verthor not installed: centre crop)";
  const note = $("#r-note");
  note.classList.toggle("hidden", S.tools.verthor || orig); note.innerHTML = "<b>verthor is not installed</b>, so clips are centre-cropped instead of following the speaker. Run <code>INSTALL_VERTHOR.bat</code> to enable subject tracking.";
  if (S.tools.verthor && !ui.vgpuAsked && S.verthor_gpu.status === "unknown") { ui.vgpuAsked = true; api("/api/verthor/gpu/check", {}); }
  const g = S.verthor_gpu, chip = $("#vgpu-chip"), vn = $("#vgpu-note");
  chip.className = "chip"; chip.textContent = ""; vn.classList.add("hidden");
  if (S.tools.verthor && !orig) {
    if (g.status === "gpu") { chip.className = "chip ok"; chip.textContent = `GPU: ${g.device || "NVIDIA"}`; }
    else if (g.status === "checking" || g.status === "unknown") { chip.textContent = "Checking GPU…"; }
    else if (g.status === "cpu") {
      chip.className = "chip warn"; chip.textContent = "verthor runs on the CPU";
      vn.classList.remove("hidden"); $("#btn-vgpu").classList.toggle("hidden", !g.can_install);
      $("#vgpu-text").textContent = g.can_install ? "verthor's PyTorch is CPU-only, which is why reframing is slow and why Fast mode is tempting. Installing the CUDA build (about 2.5 GB, one time) makes it use your NVIDIA GPU." : "verthor's PyTorch is CPU-only, and your NVIDIA driver is missing or too old for the CUDA build. Update the NVIDIA driver, then reopen this page.";
    } else if (g.status === "error") { chip.className = "chip bad"; chip.textContent = "GPU check failed"; chip.title = g.error || ""; }
  }
  $("#r-empty").classList.toggle("hidden", sel.length > 0);
  sync($("#reframes"), sel, (m) => m.id, createReframe, updateReframe);
}

function createReframe(m) {
  const el = tpl(`<div class="rf">
    <div class="side before"><div class="lab">Before</div><div class="slot slot-b" style="width:100%;display:grid;place-items:center"></div></div>
    <div class="arrow">→</div>
    <div class="side after"><div class="lab">After</div><div class="box slot-a"></div></div>
    <div class="rf-info"><span class="pillstat"></span><h4></h4><div class="m-sub"></div><div class="prog"><i></i></div><div class="rf-err"></div>
      <div class="row"><button class="btn small" data-act="play-both">▶ Play both</button><button class="btn ghost small" data-act="redo">Reframe again</button></div></div></div>`);
  el.dataset.id = m.id; return el;
}

function updateReframe(el, m) {
  const r = m.reframe, slotB = $(".slot-b", el), slotA = $(".slot-a", el);
  if (m.preview.status === "idle" && !ui.requested.has(`${m.id}.${m.ver}`)) { ui.requested.add(`${m.id}.${m.ver}`); api("/api/moments/preview", { id: m.id }); }
  setMedia(slotB, m.preview.kind === "audio" ? { status: "error", error: "no video" } : m.preview, m.id);
  const rs = r.status, wide = r.aspect === "original";
  slotA.classList.toggle("wide", wide); $(".after .lab", el).textContent = wide ? "After · original framing" : "After · 9:16";
  setAfter(slotA, r);
  const st = $(".pillstat", el); st.className = `pillstat ${rs}`;
  st.textContent = { idle: "Not reframed", queued: "Waiting…", running: `Reframing ${Math.round((r.fraction || 0) * 100)}%`, done: r.method === "verthor" ? "Subject tracked" : r.method === "original" ? "Original framing" : "Centre crop", error: "Failed" }[rs] || rs;
  $("h4", el).textContent = `#${m.id} · ${m.title}`;
  $(".m-sub", el).textContent = `${fmt(m.start)} → ${fmt(m.end)} · ${Math.round(m.duration)}s` + (rs === "done" ? ` · sound: ${r.audio}` : "");
  $(".prog i", el).style.width = `${Math.round((rs === "done" ? 1 : r.fraction || 0) * 100)}%`;
  const err = $(".rf-err", el); err.textContent = rs === "error" ? r.error : (r.warnings || []).join(" ");
  $('[data-act=play-both]', el).disabled = rs !== "done"; $('[data-act=redo]', el).disabled = jobRunning();
  el.dataset.id = m.id;
}

function setAfter(box, r) {
  const key = `${r.status}|${r.file || ""}`;
  if (box.dataset.state === key) return;
  box.dataset.state = key;
  if (r.status === "done") { const v = tpl(`<video controls preload="metadata" playsinline></video>`); v.src = media(r.file); box.replaceChildren(v); return; }
  if (r.status === "error") { box.replaceChildren(tpl(`<div class="ph"><span>Reframe failed</span></div>`)); return; }
  if (r.status === "queued" || r.status === "running") { box.replaceChildren(tpl(`<div class="ph"><span class="spinner"></span><span>${r.status === "queued" ? "Waiting…" : "Reframing…"}</span></div>`)); return; }
  box.replaceChildren(tpl(`<div class="ph"><span>Not reframed yet</span></div>`));
}

function playBoth(card) {
  const a = $(".slot-b video", card), b = $(".slot-a video", card);
  if (!a || !b) return;
  if (a.paused && b.paused) { a.currentTime = 0; b.currentTime = 0; a.play(); b.play(); }
  else { a.pause(); b.pause(); }
  [[a, b], [b, a]].forEach(([x, y]) => { x.onseeked = () => { if (Math.abs(x.currentTime - y.currentTime) > 0.35) y.currentTime = x.currentTime; }; x.onplay = () => y.paused && y.play(); x.onpause = () => !y.paused && y.pause(); });
}

// ------------------------------------------------------------------ step 4: captions
function captionOptions() {
  return { preset: ui.preset, density: ui.density, max_words: Number($("#c-words").value) || 3, max_chars: Number($("#c-chars").value) || 0, lines: ui.lines, text_case: $("#c-case").value,
    remove_punctuation: $("#c-punct").checked, size: Number($("#c-size").value) / 100, highlight: ui.colorTouched ? $("#c-color").value.replace("#", "").toUpperCase() : "",
    burn: $("#c-burn").checked, source: $("#c-source").value, autosubs_model: S.caption_opts.autosubs_model || "small" };
}

function schedulePreview() {
  clearTimeout(ui.cpTimer);
  ui.cpTimer = setTimeout(() => { if (S && !offline && S.moments.some((m) => m.reframe.status === "done")) previewCaptions(); }, 700);
}

function previewCaptions() {
  const id = Number($("#cp-clip").value);
  if (id) api("/api/captions/preview", { id, options: captionOptions() });
}

function renderStep4() {
  const done = selected().filter((m) => m.reframe.status === "done").sort((a, b) => a.start - b.start);
  // preset gallery
  const info = S.presets_info;
  $("#p-info").textContent = info.user_file ? `Loaded ${info.user_count} of your own AutoSubs preset${info.user_count === 1 ? "" : "s"} from ${info.user_file}.` : "Your own AutoSubs presets were not found automatically (AutoSubs keeps them in a file called autosubs-presets.json). Use the button below to point at it. The built-in AutoSubs presets are listed already.";
  $$("#p-filter button").forEach((b) => b.classList.toggle("on", b.dataset.f === ui.filter));
  const list = S.presets.filter((p) => ui.filter === "all" || p.source === ui.filter);
  if (!ui.thumbsAsked && S.presets.some((p) => !p.thumb)) { ui.thumbsAsked = true; api("/api/captions/thumbs"); }
  sync($("#presets"), list, (p) => p.id,
    (p) => { const el = tpl(`<div class="preset"><div class="th"></div><div class="nm"></div><div class="src"></div></div>`); el.onclick = () => { ui.preset = p.id; renderStep4(); schedulePreview(); }; return el; },
    (el, p) => {
      el.classList.toggle("on", ui.preset === p.id);
      const th = $(".th", el), k = p.thumb || "";
      if (th.dataset.k !== k) { th.dataset.k = k; if (k) { const img = tpl(`<img alt="">`); img.src = media(k); th.replaceChildren(img); } else th.replaceChildren(tpl(`<span class="spinner"></span>`)); }
      $(".nm", el).textContent = p.name; el.title = p.description || p.name;
      const sr = $(".src", el); sr.className = "src" + (p.source === "autosubs-user" ? " mine" : "");
      sr.textContent = p.source === "autosubs-user" ? "Your AutoSubs preset" : p.source === "autosubs" ? "AutoSubs" : "Sermon-Snip";
      if (p.font_found === false && p.source !== "sermonsnip") { sr.textContent += " · font not installed"; sr.classList.add("warnf"); }
    });
  // formatting widgets
  $$("#c-density button").forEach((b) => b.classList.toggle("on", b.dataset.d === ui.density));
  $("#c-custom").classList.toggle("hidden", ui.density !== "custom");
  $$("#c-lines button").forEach((b) => b.classList.toggle("on", Number(b.dataset.l) === ui.lines));
  const en = $("#e-note"), msgs = [];
  if (!S.tools.autosubs && $("#c-source").value === "autosubs") msgs.push("AutoSubs is not installed, so Sermon-Snip's own transcript will be used for captions.");
  en.classList.toggle("hidden", !msgs.length); en.textContent = msgs.join(" ");
  // clip picker + live preview
  const sel = $("#cp-clip");
  const want = done.map((m) => `${m.id}:${m.ver}`).join(",");
  if (sel.dataset.k !== want) { const cur = sel.value; sel.dataset.k = want; sel.innerHTML = done.map((m) => `<option value="${m.id}">#${m.id} · ${esc(m.title)}</option>`).join(""); if (done.some((m) => String(m.id) === cur)) sel.value = cur; }
  const m = done.find((x) => String(x.id) === sel.value) || done[0], box = $("#cp-box");
  if (!m) { box.dataset.state = ""; box.innerHTML = `<div class="ph"><span>Reframe a clip first, then preview captions here.</span></div>`; $("#cp-note").textContent = ""; }
  else {
    const p = m.cpreview, key = `${p.status}|${p.file || ""}|${m.id}`;
    if (box.dataset.state !== key) {
      box.dataset.state = key;
      if (p.status === "ready") { const v = tpl(`<video controls autoplay muted loop playsinline preload="auto"></video>`); v.src = media(p.file); box.replaceChildren(v); }
      else if (p.status === "running") box.replaceChildren(tpl(`<div class="ph"><span class="spinner"></span><span>Rendering preview…</span></div>`));
      else if (p.status === "error") { box.replaceChildren(tpl(`<div class="ph"><span>Preview failed</span><span class="small"></span></div>`)); $(".small", box).textContent = p.error || ""; }
      else box.replaceChildren(tpl(`<div class="ph"><span>Press Preview captions</span></div>`));
    }
    $("#cp-note").textContent = p.status === "ready" ? `Font used: ${p.font}. This is the real renderer: the export looks the same.` : (m.captions.status === "done" ? `Captions prepared (${m.captions.engine}, ${m.captions.words} words).` : "");
  }
  const t = S.captions_test, out = $("#cap-test-out");
  out.classList.toggle("hidden", !t);
  if (t) out.textContent = t.running ? "Testing…" : `${t.ok ? "PASS" : "FAIL"}: ${t.detail}\nFFmpeg: ${t.ffmpeg || "?"}\nass filter (libass): ${t.filters_ass}\nFont: ${t.font || "?"}`;
  $("#c-color").value = ui.colorTouched ? $("#c-color").value : (() => { const p = S.presets.find((x) => x.id === ui.preset); return $("#c-color").value; })();
}

// ------------------------------------------------------------------ step 5: export
function exportOptions() {
  return { quality: $("#e-quality").value, nvenc: $("#e-nvenc").value, sidecar_srt: $("#e-srt").checked, sidecar_ass: $("#e-ass").checked };
}

function renderStep5() {
  $("#export-path").textContent = S.export_dir;
  const q = $("#q-note"), h = S.source?.height || 0, notes = [];
  if (h && h < 1500) notes.push(`Your footage is ${S.source.width}×${h}. A vertical crop uses only about ${Math.round(h * 9 / 16)}×${h} pixels of it, which are enlarged to 1080×1920, so vertical clips look softer than the original. 4K footage gives much sharper vertical clips. (This is a property of cropping, not of the export.)`);
  if (S.nvenc === true) notes.push("NVIDIA NVENC is available and will be used for the final render.");
  q.classList.toggle("hidden", !notes.length); q.textContent = notes.join(" ");
  const fin = selected().filter((m) => m.final.status !== "idle").sort((a, b) => a.start - b.start);
  $("#f-empty").classList.toggle("hidden", fin.length > 0);
  sync($("#finals"), fin, (m) => m.id,
    (m) => tpl(`<div class="fin"><div class="box"></div><div class="nm"></div><div class="sub"></div></div>`),
    (el, m) => {
      const f = m.final, box = $(".box", el), key = `${f.status}|${f.file || ""}`;
      if (box.dataset.state !== key) {
        box.dataset.state = key;
        if (f.status === "done") { const v = tpl(`<video controls preload="metadata" playsinline></video>`); v.src = media(f.file); box.replaceChildren(v); }
        else if (f.status === "error") box.replaceChildren(tpl(`<div class="ph"><span>Failed</span></div>`));
        else box.replaceChildren(tpl(`<div class="ph"><span class="spinner"></span><span>${f.status === "queued" ? "Waiting…" : "Rendering…"}</span></div>`));
      }
      $(".nm", el).textContent = `#${m.id} · ${m.title}`;
      $(".sub", el).textContent = f.status === "done" ? `${f.engine === "autosubs" ? "AutoSubs captions" : f.engine === "builtin" ? "Built-in captions" : "No captions"}${f.burned ? " · burned in" : ""}` : f.status === "error" ? f.error : "";
    });
  const imp = $("#import-note");
  imp.textContent = S.imported ? (S.imported.waiting ? "Now run Workspace ▸ Scripts ▸ SermonSnip in Resolve." : `Imported ${S.imported.imported} of ${S.imported.total} clips into Resolve.`) : "";
}

// ------------------------------------------------------------------ GPU dialogs
function renderGpu() {
  const rec = S.gpu.recover;
  if (rec && ui.gpuShown !== rec.message) {
    ui.gpuShown = rec.message;
    const buttons = [["Install GPU libraries (≈1.3 GB)", "primary", () => api("/api/gpu/install")], ["Run on CPU instead", "", () => { $("#s-device").value = "cpu"; api("/api/analyze", analysisSettings()); }]];
    if (S.tools.autosubs) buttons.push(["Use AutoSubs engine", "", () => { $("#s-engine").value = "autosubs"; fillModels(); api("/api/analyze", analysisSettings()); }]);
    buttons.push(["Close", "ghost"]);
    modal("NVIDIA GPU transcription could not start", `${rec.message}\n\n--- Diagnosis ---\n${rec.diagnosis}\n\nNothing was switched to CPU automatically.`, buttons);
  }
  if (S.gpu.status === "done" && S.gpu.text && ui.gpuReport !== S.gpu.text) {
    ui.gpuReport = S.gpu.text;
    modal(S.gpu.ready ? "GPU is ready" : "GPU is not ready", S.gpu.text, [["Close", "primary"]]);
  }
}

// ------------------------------------------------------------------ actions
const reframedIds = () => selected().filter((m) => m.reframe.status === "done").map((m) => m.id);
const actions = {
  "pick-file": async () => { const j = await api("/api/source/file"); if (j.ok && !j.cancelled) toast("Loaded. Listening to the audio tracks…", "ok"); },
  install: async () => { const j = await api("/api/resolve/install"); if (j.ok) toast(`Installed into ${j.folder}. In Resolve, open Workspace ▸ Scripts ▸ SermonSnip.`, "ok"); },
  refresh: async () => { const j = await api("/api/resolve/refresh"); toast(j.found ? "Timeline found." : "No timeline received yet. Run SermonSnip in Resolve.", j.found ? "ok" : ""); },
  connect: async () => { const j = await api("/api/resolve/connect"); toast(j.reason || "", j.connected ? "ok" : "bad"); },
  "to-2": () => go(2),
  analyze: () => api("/api/analyze", analysisSettings()),
  rerank: () => api("/api/rerank", { target: Number($("#s-target").value) }),
  "gemini-save": async () => { const v = $("#g-key").value.trim(); const j = await api("/api/gemini/key", { key: v }); if (j.ok) { $("#g-key").value = ""; toast(v ? "Key saved on this PC." : "Key removed.", "ok"); } },
  "gemini-test": async () => { const j = await api("/api/gemini/test", { key: $("#g-key").value.trim() }); if (j.ok) toast(`Key works. ${j.models.length} models available, e.g. ${j.models.slice(0, 3).join(", ")}`, "ok"); },
  "sel-top": () => api("/api/moments/select", { ids: [...S.moments].sort((a, b) => b.score - a.score).slice(0, 5).map((m) => m.id) }),
  "sel-all": () => api("/api/moments/select", { ids: S.moments.map((m) => m.id) }),
  "sel-none": () => api("/api/moments/select", { ids: [] }),
  "adjust-toggle": (el) => el.closest(".moment").classList.toggle("open"),
  cut: () => api("/api/cut", { ids: selected().map((m) => m.id) }),
  "to-3": async () => { const j = await api("/api/reframe", { ids: selected().map((m) => m.id), options: reframeOptions() }); if (j.ok) go(3); },
  reframe: () => api("/api/reframe", { ids: selected().map((m) => m.id), options: reframeOptions() }),
  redo: (el) => api("/api/reframe", { ids: [Number(el.closest(".rf").dataset.id)], options: reframeOptions() }),
  "verthor-gpu": () => api("/api/verthor/gpu/enable"),
  "play-both": (el) => playBoth(el.closest(".rf")),
  "to-4": () => go(4),
  "to-5": () => go(5),
  "cap-preview": () => previewCaptions(),
  captions: () => api("/api/captions", { ids: reframedIds(), options: captionOptions() }),
  "cap-test": () => api("/api/captions/test"),
  "import-presets": async () => { const j = await api("/api/captions/presets/import"); if (j.ok && j.path) toast(`Found ${j.count || 0} of your AutoSubs presets.`, j.count ? "ok" : ""); },
  "color-reset": () => { ui.colorTouched = false; renderStep4(); schedulePreview(); },
  export: () => api("/api/export", { ids: reframedIds(), caption_options: captionOptions(), export_options: exportOptions() }),
  "export-all": async () => {
    const j = await api("/api/export_all", { ids: selected().map((m) => m.id), reframe_options: reframeOptions(), caption_options: captionOptions(), export_options: exportOptions() });
    if (j.ok) { view = 5; showView(); window.scrollTo({ top: 0, behavior: "smooth" }); }   // the job is already running server-side
  },
  "pick-folder": () => api("/api/export/folder"),
  "open-folder": () => api("/api/export/open"),
  import: () => api("/api/import"),
  cancel: () => api("/api/cancel"),
  "gpu-check": () => api("/api/gpu/check"),
  dismiss: () => { ui.dismissedError = S.job.error; $("#banner").classList.add("hidden"); },
  quit: async () => { await api("/api/quit"); document.body.innerHTML = '<div style="padding:80px;text-align:center;font:18px system-ui;color:#e8eef9">Sermon-Snip has stopped. You can close this window.</div>'; offline = true; },
};

document.addEventListener("click", (e) => {
  const adj = e.target.closest("[data-adj]");
  if (adj) {
    const card = adj.closest(".moment"), m = S.moments.find((x) => x.id === Number(card.dataset.id));
    if (m) {
      if (adj.dataset.adj === "reset") api("/api/moments/adjust", { id: m.id, reset: true });
      else { const [edge, d] = adj.dataset.adj.split(":"); api("/api/moments/adjust", { id: m.id, start: edge === "start" ? m.start + Number(d) : m.start, end: edge === "end" ? m.end + Number(d) : m.end }); }
    }
    return;
  }
  const t = e.target.closest("[data-act]");
  if (t && actions[t.dataset.act] && !t.disabled) actions[t.dataset.act](t);
  const pill = e.target.closest(".pill");
  if (pill) go(Number(pill.dataset.n));
});

document.addEventListener("change", (e) => {
  const cb = e.target.closest(".track input");
  if (cb) {
    cb.closest(".track").classList.toggle("on", cb.checked);
    const pick = (kind) => $$(`.track input[data-kind=${kind}]`).filter((c) => c.checked).map((c) => Number(c.dataset.index));
    api("/api/tracks", { audio: pick("audio"), video: pick("video") });
  }
  if (e.target.id === "r-aspect") renderStep3();
  if (e.target.id === "cp-clip") renderStep4();
});

setInterval(() => { if (S && view === 1 && !offline) api("/api/resolve/refresh"); }, 3000);
poll();
})();

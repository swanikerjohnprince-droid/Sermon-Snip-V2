# Architecture and verification notes

## Why an external app plus small Resolve scripts
AutoSubs' developer docs (`AGENTS.md`) state that Resolve 21.1 **Free** sandboxes the *Lua* state that runs
Workspace ▸ Scripts scripts (`io`, `ffi`, `package`, `require`, `os.execute` are nil), which is why AutoSubs itself
uses an external app plus a file mailbox. Whether Resolve's **Python** scripting is restricted the same way is
*not documented there and not known to me*; `SermonSnip_Diagnose` answers it for your install. Separately, my understanding of
Blackmagic's documentation is that Workflow Integration plugins (docked panels) require Studio; I have not verified that here.
Either way, heavy work (transcription, tracking, encoding) happens in this app, which can start processes freely, and
Resolve only needs to *import* the result.

| Piece | Runs in | Role |
|---|---|---|
| `app.py`, `analyzer.py`, `pipeline.py` | Python desktop app | analysis, cutting, orchestration |
| `gpu_setup.py` | desktop app | CUDA discovery, loading, diagnosis |
| `reframe.py` → verthor CLI | subprocess | 9:16 subject-tracked render |
| `autosubs_cli.py` → AutoSubs CLI | subprocess | transcripts and caption SRTs |
| `resolve_script/SermonSnip_Import.py` | inside Resolve | builds timelines from `manifest.json` |

`~/SermonSnip/last_manifest.txt` and `last_highlights.txt` hold the latest export path so Resolve scripts need no file dialog.

## Contracts (read from source, not assumed)
**verthor** (`KazKozDev/auto-vertical-reframe`, MIT, commit pinned in `INSTALL_VERTHOR.bat`): `verthor IN OUT --preset
--start --duration --video-encoder --crf [--fast]`; flags confirmed by parsing its argparse. It extracts the time
window itself, so we pass the **original** file (no extra lossy generation). It defaults to Apple's VideoToolbox
encoder, so we pass `libx264`. No camera path is exported, so output is a baked MP4. Progress lines `Processed n/N` are parsed.

**AutoSubs** (`tmoroney/auto-subs`, MIT, tested against 3.11.0): `autosubs FILE -m MODEL -f srt|json -o OUT [-l LANG]
[--density custom --max-lines 1 --max-words-per-line 4] [--no-gpu] [--prompt TEXT]`. On Windows the release binary is a
GUI-subsystem exe whose stdout/stderr "go nowhere" when launched by another program (documented in its `cli.rs`),
so we **always use `-o`** and judge success by exit code **and** the file existing. The JSON follows
`transcript_types.rs`; we read `originalSegments` (raw segments) with word times.
Headless runs bypass its single-instance plugin, so it can run while the AutoSubs window is open.

## Verified here
- DLL names, load mechanism and bundled cuDNN version in the real `ctranslate2 4.8.3` Windows wheel (PE analysis).
- NVIDIA wheels exist for Windows and pip resolves `requirements-gpu.txt` for win_amd64/cp312.
- AutoSubs 3.11.0 Linux CLI runs (`--version`, `--list-models`) and its error contract (exit 1, JSON on stderr).
- All wrappers, fallbacks, cancel, manifest and the Resolve import logic against fake CLIs and a mock Resolve API (see `tests/`).
- Three bugs in the previous analyzer, now covered by regression tests: overlapping near-duplicate clips, 44.1/48 kHz audio
  passed to Whisper as 16 kHz, and DLL registration that CTranslate2 does not consult.

## NOT verified (please test; each has a diagnostic)
1. **GPU on your RTX 4050**: run `CHECK_GPU.bat`.
2. **Resolve scripting permissions** on your edition: run `SermonSnip_Diagnose`. If file access or tkinter is blocked in
   Free, `SermonSnip_Import` may need a different way to receive the manifest.
3. **`SermonSnip_Import` API behaviour** (`SetSetting` on an empty timeline, `AppendToTimeline`) on your Resolve version.
4. **Marker timecode offset** (`SermonSnip_Markers`): `ADD_TIMELINE_START_FRAME` / `SOURCE_OFFSET_SECONDS` may need flipping.
5. **verthor on Windows**: untested upstream; real speed on CPU unknown. Use **Fast**, try one clip first.
6. **AutoSubs headless on Windows**: output file is the success signal; if captions silently fall back to built-in,
   run the printed command in a terminal to see AutoSubs' message.
7. **AutoSubs SRT import timing** onto a timeline starting at 01:00:00:00.

## Licensing
Sermon-Snip drives both tools as separate processes. verthor and AutoSubs are MIT. In AutoSubs' model list only the optional
MMS forced-alignment model is CC BY-NC (not used here); Whisper models are fine.


## v0.6: the four-step web interface

**Why a local web UI:** Tk cannot play two synchronised videos with sound. A small stdlib HTTP server (`server.py`) plus a
dependency-free front end (`web/`) gives real `<video>` previews, Range-request scrubbing and before/after players.
Nothing is downloaded at run time and nothing leaves the machine. Security: bound to 127.0.0.1, a per-launch token on every
API call and media URL, `Host` header check (DNS-rebinding), media served only from the session's work/export folders
(path traversal tested).

| Layer | File | Role |
|---|---|---|
| UI | `web/index.html`, `app.css`, `app.js` | stepper, keyed reconciler (playing videos are never rebuilt on progress updates) |
| API | `server.py` | JSON routes, Range media, token/host checks |
| Workflow | `session.py` | the 4 steps as background jobs; one heavy job at a time; Cancel; state with a revision counter |
| Tracks to media | `resolve_map.py` | snapshot -> pieces (higher video track wins), mixdown of only the chosen audio tracks, range rendering |
| Resolve | `resolve_bridge.py`, `resolve_link.py` | runs inside Resolve (generated scripts) or directly in Studio |
| Captions | `captions.py` | word timings -> ASS (word highlight) / SRT, burned with FFmpeg |

**Tracks.** `SermonSnip_Export` writes a snapshot: per track, per item: media file, timeline start/end (seconds, relative to
the timeline start, so the 01:00:00:00 offset is removed) and the source in-point. The app decodes only the chosen audio
tracks into one 16 kHz analysis file (disk-backed, so long sermons are fine). Previews, reframing and cutting all map a
moment's timeline range back to source files through the same function.

**Cutting into Resolve.** One timeline per moment; the original media-pool clips are appended trimmed (`AppendToTimeline`
with `startFrame`/`endFrame`/`trackIndex`/`recordFrame`). Rules taken from AutoSubs' own Resolve code and enforced by a
mock that reproduces them: integer frames only (a float fails the whole batch), dead-handle detection after an append,
absolute frame numbers.

**Captions.** AutoSubs returns word timings (`-f json`); `captions.py` groups 1-6 words per line, highlights the spoken word
and burns it with `ass=` + `setsar=1` (square pixels). Without AutoSubs the built-in transcript is used and the clip says so.

### Verified in this release
- Real Chromium (v153), driving the actual UI against the real server: **25/25 checks** (screenshots reviewed):
  Resolve tracks listed by name, only the pastor mic selected, moments + playing video previews, strongest-sentence titles,
  cut job -> "Created 4 timeline(s)", before 16:9 / after 9:16, *Play both* in sync (|dt| < 0.6 s), caption style defaults,
  exported clips 1080x1920 and playing, no JavaScript errors.
- Backend: 28 API tests (security, range requests, the full workflow, fallbacks, cancel, GPU-error recovery, caching,
  Resolve cut round-trip), 18 media-mapping tests with synthetic tones proving the right audio lands at the right time,
  mock-Resolve tests for the bridge.
- The generated Resolve scripts are executed against the mock exactly as Resolve would run them.

### NOT verified (needs your machine; each has a diagnostic)
1. **Real Resolve.** The mock encodes documented behaviour, not Resolve itself. Run `SermonSnip_Diagnose`: it prints the
   exact values the snapshot depends on (`GetLeftOffset`, `GetSourceStartFrame`, clip FPS, file path, start frame).
   The in-point unit (clip frames vs timeline frames) for clips whose fps differs from the timeline is an assumption; a
   warning is attached to such clips. The preview in step 2 is your visual check that the mapping is right.
2. Whether Resolve Free's **Python** scripting can write the hand-off files (see above). Direct mode needs Studio.
3. Real verthor / AutoSubs output (fakes implement the verified CLI contract). verthor output with non-square pixels
   is normalised by the caption burn-in.
4. Edge/Chrome "app mode" window launching on Windows (falls back to your default browser).


## v0.7 additions

**Caption engine (`caption_style.py`).** AutoSubs stores presets in `<app data>/com.autosubs/autosubs-presets.json` (key `userPresets`; read from AutoSubs' own
`PresetsContext.tsx`). Each preset holds raw inputs of the AutoSubs Fusion macro; `style_from_fusion` maps them (Font/Style/TextSize/TextPosition, Fill, Outline,
Shadow, Highlight with the macro's own style ids 0 Fill / 1 Outline / 2 Glow / 3 Bubble, PopIn/Fade/SlideUp) to ASS. Built-in presets are extracted from AutoSubs' source
into `data/autosubs_builtin_presets.json` (MIT). Burn-in copies the font file beside the subtitle file and uses `ass=filename=x.ass:fontsdir=.`, so it cannot be broken
by Windows fontconfig or missing fonts; bundled font: Poppins (OFL, `fonts/`). `selftest()` proves captions are drawn (frame differs from the plain frame).

**Track detection (`resolve_map.py`).** `file_snapshot` makes one track per audio stream; `annotate_levels` measures each (`volumedetect` at three points);
`auto_select` picks the likeliest speech track. Resolve snapshots are annotated the same way from the media files.

**One Resolve script.** `SermonSnip.py` (generated from `resolve_bridge.py`) does whichever is pending: cut job, import request, otherwise it sends the timeline.
It never re-captures while work is pending (after a cut Resolve's current timeline is a new one), and cutting returns you to your sermon timeline.

**verthor GPU (`verthor_gpu.py`).** Checks what verthor's own PyTorch sees; installs the CUDA wheel whose folder matches the driver's CUDA capability
(`cu126`/`cu128`/`cu130` under download.pytorch.org/whl). `--device 0` is passed when CUDA works. Fast mode is off by default.

**Pipeline stages and quality.** reframe (near-lossless intermediate) -> captions (words cached; style changes never re-transcribe) -> render (the only quality-bearing
encode; NVENC if a real trial encode succeeds). `Export all` runs the missing stages per clip and skips finished ones.

### Verified in this release
- Real Chromium, real server: **34/34** checks on the full five-step journey and **10/10** on the cold-start *Export all* path (screenshots reviewed). They covered:
  auto-selected speaker track, single Resolve script, adjust + reset, preview rebuild, Gemini panel, CPU-only banner, before/after (16:9 / 9:16) in sync,
  preset gallery with the user's own presets, live caption preview, caption self-test, captions prepared as their own stage, quality options, 1080x1920 exports.
- Caption tests include the Windows failure mode: a preset font installed nowhere still renders (bundled font), square pixels, audio kept.
- Bugs found by these tests and fixed: caption events overlapping by ~20 ms (double-drawn text), analysis padding leaking 1 s into the media duration,
  the "adjusted" label sticking after Reset, Export all refused before anything was reframed.

### NOT verified
1. **Your burn-in failure** was not reproducible here (Linux). The new design removes the likeliest causes; the self-test will tell us if it is something else.
2. **verthor on a GPU, the CUDA PyTorch install, the FFmpeg PowerShell installer and the Gemini live API** were not run (no GPU/Windows/network access to those services here).
   They are covered by fakes/mocks of their documented contracts only.
3. **Real Resolve** (see v0.6 notes) and AutoSubs' own Fusion rendering (our render is a close reproduction).

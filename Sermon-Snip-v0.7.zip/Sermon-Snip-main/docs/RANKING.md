# Ranking moments: local scoring vs Gemini

**What the local scorer is good at:** finding *where to look*. It is free, offline, fast and predictable: delivery energy (the preacher raising the
voice), key phrases (whole-word matching, with a penalty for announcements), and clip edges on sentence boundaries.

**What it cannot do:** judge *meaning*. It scores "God is able" the same whether it is the climax of a story or a throwaway line, cannot tell that a clip
leans on context ("as I said earlier"), and its phrase score saturates (several strong phrases all give ~100%), so many candidates tie.

**What a language model adds:** judgement of hook, completeness, a single clear message, quotability, and dependence on context, plus a better title.
That is the part people actually experience as "good clip / bad clip".

**Why re-rank instead of replace:**
- Cost and speed: only ~30 shortlisted candidates (about 4,500 words) are sent, not the sermon. A sermon is typically cents or less on a paid key.
- Reliability: a model asked to invent timestamps for a 90-minute transcript will sometimes invent wrong ones. Re-judging fixed candidates cannot.
- Privacy: transcript text of the shortlist only; never audio/video. The free tier of the Gemini API may use submitted content to improve Google's products;
  the paid tier does not. Off by default; needs your own key (`GEMINI_API_KEY` or the field in Step 2). The key is stored locally and never sent back to the page.
- Blending: final score = trust × Gemini + (1 − trust) × local (default trust 70%). If Gemini fails (quota, key, network) the local ranking is kept and the reason is shown.

**Evidence level:** the integration is tested against a mock of Google's API (request shape, structured JSON output, key as a header, error handling, id validation,
score clamping). It has **not** been run against the live API or compared with human judgement on real sermons. Judge it on your own sermons: run once with it off and once on, and
see which top five you would post. The default model alias is `gemini-flash-latest` (editable); Google renames models often.

# Run from DaVinci Resolve: Workspace > Scripts > SermonSnip_Markers
# (copy this file into Resolve's Scripts/Utility folder first).
# Adds a marker for each highlight in a Sermon-Snip JSON export to the CURRENT timeline.
import json
import os
import re

# --- Settings ---------------------------------------------------------------------------
# Seconds into the timeline where the sermon audio/video begins. 0 if the sermon clip is
# the first thing on the timeline; otherwise set the offset in seconds.
SOURCE_OFFSET_SECONDS = 0.0
# Resolve's AddMarker() frame position is normally relative to the timeline's first frame.
# If markers appear exactly one hour late (timeline starts at 01:00:00:00), set this to True.
ADD_TIMELINE_START_FRAME = False
# Sermon-Snip leaves the path of your latest highlights export in this file, so no dialog is needed.
POINTER_FILE = os.path.join(os.path.expanduser("~"), "SermonSnip", "last_highlights.txt")
# ----------------------------------------------------------------------------------------


def pick_file():
    """Latest export (via the pointer file) first; file dialog only as a fallback."""
    try:
        with open(POINTER_FILE, "r", encoding="utf-8") as stream:
            path = stream.read().strip()
        if path and os.path.exists(path):
            return path
    except OSError:
        pass
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        path = filedialog.askopenfilename(title="Choose Sermon-Snip highlight JSON",
                                          filetypes=[("JSON", "*.json")])
        root.destroy()
        return path
    except Exception:
        return ""


def message(text):
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showinfo("Sermon-Snip", text)
        root.destroy()
    except Exception:
        print("Sermon-Snip:", text)


def timeline_fps(timeline):
    """Parse '23.976', '29.97 DF', '30' ... Falls back to 24 only if the setting is unreadable."""
    try:
        match = re.search(r"[0-9]+(?:\.[0-9]+)?", str(timeline.GetSetting("timelineFrameRate")))
        if match:
            return float(match.group(0))
    except Exception:
        pass
    return 24.0


def marker_color(score):
    return "Green" if score >= 60 else "Cyan" if score >= 40 else "Blue"


def main():
    path = pick_file()
    if not path:
        return
    with open(path, "r", encoding="utf-8") as stream:
        data = json.load(stream)
    try:
        project = resolve.GetProjectManager().GetCurrentProject()  # noqa: F821  (provided by Resolve)
        timeline = project.GetCurrentTimeline() if project else None
    except Exception:
        timeline = None
    if not timeline:
        message("Open a project and select a timeline first.")
        return
    fps = timeline_fps(timeline)
    base = 0
    if ADD_TIMELINE_START_FRAME:
        try:
            base = int(timeline.GetStartFrame())
        except Exception:
            base = 0
    added = skipped = 0
    for h in data.get("highlights", []):
        start = float(h.get("start", 0)) + SOURCE_OFFSET_SECONDS
        end = float(h.get("end", 0)) + SOURCE_OFFSET_SECONDS
        frame = base + max(0, int(round(start * fps)))
        duration = max(1, int(round((end - start) * fps)))
        score = float(h.get("score", 0) or 0)
        label = f"{score:.0f} {h.get('title') or 'Highlight'}"[:60]
        note = str(h.get("text", ""))[:900]
        try:
            ok = timeline.AddMarker(frame, marker_color(score), label, note, duration, "Sermon-Snip")
        except Exception:
            ok = False
        added, skipped = added + bool(ok), skipped + (not ok)
    message(f"Added {added} marker(s) at {fps:g} fps" + (f"; {skipped} skipped (a marker already "
            "exists on that frame, or Resolve refused it)." if skipped else ".") +
            "\nCheck the first marker against the audio. If it is offset, adjust the two settings at the top of the script.")


if __name__ == "__main__":
    main()

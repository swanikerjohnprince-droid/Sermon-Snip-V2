# Run from DaVinci Resolve: Workspace > Scripts > SermonSnip_Diagnose
# Reports what your Resolve edition lets scripts do (file access, dialogs, API), so the other
# Sermon-Snip scripts can be fixed against facts instead of guesses. Output goes to the Console
# (Workspace > Console) and, if file writing works, to ~/SermonSnip/resolve_diagnosis.txt
import os
import sys
import traceback

lines = []


def check(name, fn):
    try:
        lines.append("[ OK ] %s: %s" % (name, fn()))
    except Exception as exc:
        lines.append("[FAIL] %s: %s: %s" % (name, type(exc).__name__, exc))


home = os.path.expanduser("~")
folder = os.path.join(home, "SermonSnip")


def _write():
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, "_probe.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write("probe")
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    os.remove(path)
    return "wrote/read/deleted " + path + " -> " + data


def _tk():
    import tkinter as tk
    root = tk.Tk()
    root.withdraw()
    root.destroy()
    return "tkinter dialogs available"


def _subprocess():
    import subprocess
    out = subprocess.run([sys.executable or "python", "--version"], capture_output=True, text=True, timeout=10)
    return "can start processes (%s)" % (out.stdout.strip() or out.stderr.strip() or "no output")


def _api():
    r = resolve  # noqa: F821
    pm = r.GetProjectManager()
    project = pm.GetCurrentProject()
    timeline = project.GetCurrentTimeline() if project else None
    return "Resolve %s | project=%s | timeline=%s | fps setting=%s" % (
        r.GetVersionString(), project.GetName() if project else None,
        timeline.GetName() if timeline else None,
        timeline.GetSetting("timelineFrameRate") if timeline else "n/a")


def _timeline_start():
    project = resolve.GetProjectManager().GetCurrentProject()  # noqa: F821
    timeline = project.GetCurrentTimeline()
    return "start frame=%s start timecode=%s" % (timeline.GetStartFrame(), timeline.GetStartTimecode())


def _items():
    """The values SermonSnip_Export relies on, for the first clip of each track. Send me this if clips land at the wrong time."""
    project = resolve.GetProjectManager().GetCurrentProject()  # noqa: F821
    timeline = project.GetCurrentTimeline()
    out = ["timeline fps=%s start frame=%s" % (timeline.GetSetting("timelineFrameRate"), timeline.GetStartFrame())]
    for kind in ("video", "audio"):
        for i in range(1, int(timeline.GetTrackCount(kind) or 0) + 1):
            items = timeline.GetItemListInTrack(kind, i) or []
            if not items:
                out.append("%s %d (%s): empty" % (kind, i, timeline.GetTrackName(kind, i)))
                continue
            it = items[0]
            def val(name, *args):
                try:
                    return getattr(it, name)(*args)
                except Exception as exc:
                    return "n/a (%s)" % type(exc).__name__
            mpi = val("GetMediaPoolItem")
            props = {}
            for key in ("File Path", "FPS", "Start TC"):
                try:
                    props[key] = mpi.GetClipProperty(key)
                except Exception:
                    props[key] = "n/a"
            out.append("%s %d (%s) first of %d: start=%s end=%s leftOffset=%s sourceStartFrame=%s sourceEndFrame=%s | %s" % (
                kind, i, timeline.GetTrackName(kind, i), len(items), val("GetStart"), val("GetEnd"), val("GetLeftOffset"),
                val("GetSourceStartFrame"), val("GetSourceEndFrame"), props))
    return "\n      ".join(out)


check("Timeline items (what Sermon-Snip reads)", _items)
check("Python", lambda: sys.version.split()[0] + " " + (sys.executable or "(embedded)"))
check("Resolve API", _api)
check("Timeline start", _timeline_start)
check("File read/write in home folder", _write)
check("tkinter dialogs", _tk)
check("subprocess (needed to launch external tools)", _subprocess)
check("os.system present", lambda: str(hasattr(os, "system")))

report = "\n".join(lines)
print(report)
try:
    os.makedirs(folder, exist_ok=True)
    with open(os.path.join(folder, "resolve_diagnosis.txt"), "w", encoding="utf-8") as f:
        f.write(report)
except Exception:
    traceback.print_exc()
try:
    import tkinter as tk
    from tkinter import messagebox
    root = tk.Tk()
    root.withdraw()
    messagebox.showinfo("Sermon-Snip diagnosis", report)
    root.destroy()
except Exception:
    pass

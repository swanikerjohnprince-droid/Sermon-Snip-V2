"""Stand-in for the AutoSubs CLI (flags verified against AutoSubs' tauri.conf.json / cli.rs)."""
import argparse
import json
import os
import sys

ap = argparse.ArgumentParser()
ap.add_argument("input"); ap.add_argument("-m", "--model", default="small"); ap.add_argument("-f", "--format", default="srt")
ap.add_argument("-o", "--output"); ap.add_argument("-l", "--lang"); ap.add_argument("--density")
ap.add_argument("--max-lines"); ap.add_argument("--max-words-per-line"); ap.add_argument("--no-gpu", action="store_true")
ap.add_argument("--prompt")
a = ap.parse_args()
log = os.environ.get("FAKE_ARGS_LOG")
if log:
    open(log, "w").write(" ".join(sys.argv[1:]))
mode = os.environ.get("FAKE_MODE", "ok")
if mode == "silent_fail":            # Windows GUI-subsystem behaviour: exit 1, nothing visible anywhere
    sys.exit(1)
if mode == "error":
    print('{"error":"Transcription failed: model download blocked"}', file=sys.stderr); sys.exit(1)
if mode == "noexit_nofile":          # exit 0 but no file written (e.g. intercepted by another instance)
    sys.exit(0)
os.makedirs(os.path.dirname(os.path.abspath(a.output)), exist_ok=True)
if a.format == "json":
    data = {"language": "en", "processing_time_sec": 1.0,
            "segments": [{"start": 0, "end": 2, "text": "Short display cue."}],
            "originalSegments": [
                {"start": 0.0, "end": 4.0, "text": " Listen to me, God is able. ",
                 "words": [{"word": "Listen", "start": 0.0, "end": 0.5}, {"word": "to", "start": 0.5, "end": 0.7}]},
                {"start": 4.0, "end": 9.5, "text": "Do not give up!"}]}
    open(a.output, "w", encoding="utf-8").write(json.dumps(data))
else:
    open(a.output, "w", encoding="utf-8").write("1\n00:00:00,000 --> 00:00:02,000\nAutoSubs caption\n\n")

"""Stand-in for the `verthor` CLI, implementing the flags Sermon-Snip uses (checked against verthor's argparse)."""
import argparse
import os
import subprocess
import sys

ap = argparse.ArgumentParser()
ap.add_argument("input"); ap.add_argument("output")
ap.add_argument("--preset", default="talking_head"); ap.add_argument("--start", type=float, default=0.0)
ap.add_argument("--duration", type=float, default=None); ap.add_argument("--video-encoder", default="h264_videotoolbox")
ap.add_argument("--crf", type=int, default=18); ap.add_argument("--fast", action="store_true")
ap.add_argument("--device", default=None); ap.add_argument("--preset-ffmpeg", default="medium")
a = ap.parse_args()
if os.environ.get("FAKE_FAIL"):
    print("ERROR: could not open input", file=sys.stderr); sys.exit(2)
log = os.environ.get("FAKE_ARGS_LOG")
if log:
    open(log, "w").write(" ".join(sys.argv[1:]))
for n in (10, 20):
    print(f"INFO Processed {n}/20 frames", file=sys.stderr, flush=True)
if os.environ.get("FAKE_SLOW"):
    import time; time.sleep(30)
cmd = ["ffmpeg", "-y", "-loglevel", "error", "-ss", str(a.start), "-i", a.input, "-t", str(a.duration),
       "-vf", "crop=w='min(iw,ih*9/16)':h=ih,scale=1080:1920,setsar=1", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
       "-c:a", "aac", a.output]
sys.exit(subprocess.run(cmd).returncode)

"""Track selection -> real media: pieces, analysis mixdown, range rendering (synthetic files with known tones)."""
import shutil
import subprocess
import sys
import tempfile
import unittest
import wave
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import media  # noqa: E402
import resolve_map as rm  # noqa: E402
from scene_detect import probe_video  # noqa: E402

HAVE_FFMPEG = media.ffmpeg_available()
D = {}


def tone(path, freq, seconds):
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"sine=f={freq}:d={seconds}:r=44100", str(path)], check=True)


def video(path, seconds, color):
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"color=c={color}:s=640x360:r=25:d={seconds}",
                    "-f", "lavfi", "-i", f"sine=f=200:d={seconds}", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(path)], check=True)


def setUpModule():
    if not HAVE_FFMPEG:
        return
    D["dir"] = Path(tempfile.mkdtemp())
    d = D["dir"]
    tone(d / "mic_a.wav", 440, 20)       # preacher, first half
    tone(d / "mic_b.wav", 880, 30)       # preacher, second half (we use its seconds 5..25)
    tone(d / "music.wav", 1500, 40)      # background music: should be excluded when not selected
    video(d / "cam_red.mp4", 20, "red")
    video(d / "cam_blue.mp4", 30, "blue")


def tearDownModule():
    shutil.rmtree(D.get("dir", "."), ignore_errors=True) if D else None


def item(i, f, start, end, src_in=0.0):
    return {"i": i, "name": Path(f).name if f else "", "file": str(D["dir"] / f) if f else None, "start": start, "end": end, "src_in": src_in, "warnings": []}


def snapshot():
    return {"schema": 1, "source": "resolve", "timeline": "Sunday", "fps": 25.0, "width": 640, "height": 360, "duration": 40.0, "warnings": [],
            "tracks": [
                {"type": "audio", "index": 1, "name": "Music", "enabled": True, "items": [item(0, "music.wav", 0, 40)]},
                {"type": "audio", "index": 2, "name": "Pastor", "enabled": True,
                 "items": [item(0, "mic_a.wav", 0, 20), item(1, "mic_b.wav", 20, 40, src_in=5.0)]},
                {"type": "video", "index": 1, "name": "Camera", "enabled": True,
                 "items": [item(0, "cam_red.mp4", 0, 20), item(1, "cam_blue.mp4", 20, 40, src_in=5.0)]},
            ]}


def dominant_freq(samples, rate):
    spec = np.abs(np.fft.rfft(samples * np.hanning(len(samples))))
    return np.fft.rfftfreq(len(samples), 1 / rate)[int(spec.argmax())]


def read_wav(path):
    with wave.open(str(path)) as wf:
        return wf.getframerate(), np.frombuffer(wf.readframes(wf.getnframes()), dtype="<i2").astype(np.float32) / 32768


class PureLogicTests(unittest.TestCase):
    """No FFmpeg needed."""

    def snap(self):
        return {"tracks": [
            {"type": "video", "index": 1, "items": [item_(0, "a.mp4", 0, 10), item_(1, "b.mp4", 10, 20, 5.0)]},
            {"type": "video", "index": 2, "items": [item_(0, "c.mp4", 12, 14)]},   # cutaway above V1
            {"type": "audio", "index": 1, "items": [item_(0, "x.wav", 0, 20)]}]}

    def test_piece_inside_one_item_maps_to_source_time(self):
        pieces = rm.video_pieces(self.snap(), [1], 12.0, 18.0)
        self.assertEqual(len(pieces), 1)
        self.assertEqual((pieces[0]["path"], pieces[0]["src_start"], pieces[0]["src_end"]), ("b.mp4", 7.0, 13.0))

    def test_range_spanning_two_clips_gives_two_pieces(self):
        pieces = rm.video_pieces(self.snap(), [1], 8.0, 12.0)
        self.assertEqual([(p["path"], round(p["src_start"], 2), round(p["src_end"], 2)) for p in pieces], [("a.mp4", 8.0, 10.0), ("b.mp4", 5.0, 7.0)])

    def test_higher_track_wins_where_they_overlap(self):
        pieces = rm.video_pieces(self.snap(), [1, 2], 10.0, 16.0)
        self.assertEqual([(p["path"], p["tl_start"], p["tl_end"]) for p in pieces], [("b.mp4", 10.0, 12.0), ("c.mp4", 12.0, 14.0), ("b.mp4", 14.0, 16.0)])

    def test_unselected_track_is_ignored(self):
        pieces = rm.video_pieces(self.snap(), [1], 12.0, 14.0)
        self.assertEqual([p["path"] for p in pieces], ["b.mp4"])

    def test_gap_is_reported_not_skipped(self):
        snap = {"tracks": [{"type": "video", "index": 1, "items": [item_(0, "a.mp4", 0, 5), item_(1, "b.mp4", 8, 12)]}]}
        pieces = rm.video_pieces(snap, [1], 3.0, 10.0)
        self.assertEqual([p["gap"] for p in pieces], [False, True, False])

    def test_items_without_a_file_are_skipped(self):
        snap = {"tracks": [{"type": "video", "index": 1, "items": [item_(0, None, 0, 10)]}]}
        self.assertTrue(all(p["gap"] for p in rm.video_pieces(snap, [1], 2.0, 4.0)))

    def test_track_summary_flags_unusable_items(self):
        snap = {"tracks": [{"type": "audio", "index": 1, "name": "A1", "items": [item_(0, "x.wav", 0, 10), item_(1, None, 10, 20)]}]}
        s = rm.track_summary(snap)[0]
        self.assertEqual((s["items"], s["usable"], s["covered"]), (2, 1, 10.0))


def item_(i, f, start, end, src_in=0.0):
    return {"i": i, "file": f, "start": start, "end": end, "src_in": src_in, "warnings": []}


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg not installed")
class MediaTests(unittest.TestCase):
    def test_analysis_audio_contains_only_the_chosen_tracks_at_the_right_times(self):
        out = D["dir"] / "mix_pastor.wav"
        duration = rm.render_analysis_audio(snapshot(), [2], out)
        self.assertAlmostEqual(duration, 40.0, delta=0.1)
        rate, x = read_wav(out)
        self.assertEqual(rate, 16000)
        self.assertAlmostEqual(dominant_freq(x[5 * rate:15 * rate], rate), 440, delta=15)    # first half = mic_a
        self.assertAlmostEqual(dominant_freq(x[25 * rate:35 * rate], rate), 880, delta=15)   # second half = mic_b
        # music (1500 Hz) must be absent
        spec = np.abs(np.fft.rfft(x[5 * rate:15 * rate]))
        freqs = np.fft.rfftfreq(10 * rate, 1 / rate)
        self.assertLess(spec[(freqs > 1450) & (freqs < 1550)].max(), 0.02 * spec.max())

    def test_choosing_both_tracks_mixes_them(self):
        out = D["dir"] / "mix_both.wav"
        rm.render_analysis_audio(snapshot(), [1, 2], out)
        rate, x = read_wav(out)
        seg = np.abs(np.fft.rfft(x[5 * rate:15 * rate]))
        freqs = np.fft.rfftfreq(10 * rate, 1 / rate)
        for f in (440, 750 + 750):      # 440 from the pastor, 1500 from the music
            self.assertGreater(seg[(freqs > f - 20) & (freqs < f + 20)].max(), 0.2 * seg.max())

    def test_source_offset_is_honoured(self):
        # mic_b item starts 5 s into its file. A 1000 Hz burst only at source seconds 0-5 must NOT appear.
        d = D["dir"]
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "sine=f=1000:d=5:r=16000", "-f", "lavfi", "-i", "sine=f=300:d=15:r=16000",
                        "-filter_complex", "[0][1]concat=n=2:v=0:a=1", str(d / "marked.wav")], check=True)
        snap = {"tracks": [{"type": "audio", "index": 1, "items": [item(0, "marked.wav", 0, 10, src_in=5.0)]}]}
        out = d / "off.wav"
        rm.render_analysis_audio(snap, [1], out)
        rate, x = read_wav(out)
        self.assertAlmostEqual(dominant_freq(x[1 * rate:9 * rate], rate), 300, delta=15)

    def test_unusable_selection_is_a_clear_error(self):
        snap = {"tracks": [{"type": "audio", "index": 1, "items": [item(0, None, 0, 10)]}]}
        with self.assertRaisesRegex(rm.MapError, "no media files"):
            rm.render_analysis_audio(snap, [1], D["dir"] / "x.wav")

    def test_render_range_across_two_clips_has_both_pictures_and_right_length(self):
        pieces = rm.video_pieces(snapshot(), [1], 15.0, 25.0)       # 5 s red + 5 s blue
        out = rm.render_video_range(pieces, D["dir"] / "two.mp4", size=(320, 180))
        info = probe_video(out)
        self.assertEqual((info["width"], info["height"]), (320, 180))
        self.assertAlmostEqual(info["duration"], 10.0, delta=0.3)
        frames = []
        for t in (2.0, 8.0):
            png = D["dir"] / f"f{t}.png"
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", str(t), "-i", str(out), "-frames:v", "1", str(png)], check=True)
            frames.append(png.read_bytes())
        self.assertNotEqual(frames[0], frames[1])

    def test_gap_becomes_black_and_keeps_length(self):
        snap = {"tracks": [{"type": "video", "index": 1, "items": [item(0, "cam_red.mp4", 0, 5), item(1, "cam_blue.mp4", 8, 12)]}]}
        pieces = rm.video_pieces(snap, [1], 3.0, 10.0)
        out = rm.render_video_range(pieces, D["dir"] / "gap.mp4", size=(160, 90))
        self.assertAlmostEqual(probe_video(out)["duration"], 7.0, delta=0.3)

    def test_vertical_centre_crop_output_size(self):
        pieces = rm.video_pieces(snapshot(), [1], 2.0, 6.0)
        out = rm.render_video_range(pieces, D["dir"] / "v.mp4", vertical_center=True)
        info = probe_video(out)
        self.assertEqual((info["width"], info["height"]), (1080, 1920))

    def test_chosen_audio_tracks_can_replace_the_cameras_own_sound(self):
        pieces = rm.video_pieces(snapshot(), [1], 2.0, 8.0)
        ap = rm.audio_pieces_by_track(snapshot(), [2], 2.0, 8.0)
        out = rm.render_video_range(pieces, D["dir"] / "swap.mp4", size=(160, 90), audio_pieces=ap)
        wav = D["dir"] / "swap.wav"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(out), "-vn", "-ac", "1", "-ar", "16000", str(wav)], check=True)
        rate, x = read_wav(wav)
        self.assertAlmostEqual(dominant_freq(x[rate:5 * rate], rate), 440, delta=20)    # pastor mic, not camera's 200 Hz

    def test_file_snapshot_of_a_video_has_audio_and_video_tracks(self):
        snap = rm.file_snapshot(D["dir"] / "cam_red.mp4")
        self.assertEqual([(t["type"], len(t["items"])) for t in snap["tracks"]], [("audio", 1), ("video", 1)])
        self.assertAlmostEqual(snap["duration"], 20.0, delta=0.3)

    def test_file_snapshot_of_audio_only_has_no_video_track(self):
        snap = rm.file_snapshot(D["dir"] / "mic_a.wav")
        self.assertEqual([t["type"] for t in snap["tracks"]], ["audio"])

    def test_snapshot_signature_changes_with_selection(self):
        s = snapshot()
        self.assertNotEqual(rm.snapshot_signature(s, [1]), rm.snapshot_signature(s, [2]))


if __name__ == "__main__":
    unittest.main()

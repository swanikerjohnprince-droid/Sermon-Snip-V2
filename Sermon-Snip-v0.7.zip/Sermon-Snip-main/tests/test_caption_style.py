"""Caption styles: AutoSubs preset mapping, user-preset loading, fonts, ASS output, and the burn-in self-test."""
import json
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import caption_style as cs  # noqa: E402
import captions as cap  # noqa: E402
import media  # noqa: E402

HAVE_FFMPEG = media.ffmpeg_available()


def words(text, step=0.4, start=0.0):
    return [{"word": w, "start": start + i * step, "end": start + i * step + 0.3} for i, w in enumerate(text.split())]


def events(ass):
    return [re.match(r"Dialogue: 0,([^,]+),([^,]+),Default,,0,0,0,,(.*)", l).groups() for l in ass.splitlines() if l.startswith("Dialogue")]


def secs(t):
    h, m, s = t.split(":")
    return int(h) * 3600 + int(m) * 60 + float(s)


MACRO = {"Font": "Arial Rounded MT Bold", "Style": "Bold", "TextSize": 0.07, "TextPosition": [0.5, 0.12, 0], "FillColorRed": 1, "FillColorGreen": 1, "FillColorBlue": 1,
         "OutlineEnabled": 1, "OutlineThickness": 0.08, "OutlineColorRed": 0, "OutlineColorGreen": 0, "OutlineColorBlue": 0, "ShadowEnabled": 0,
         "HighlightEnabled": 1, "HighlightStyle": 3, "HighlightColorRed": 1, "HighlightColorGreen": 0, "HighlightColorBlue": 0,
         "PopInEnabled": 1, "FadeEnabled": 0, "SlideUpEnabled": 0, "AnimationLength": 0.2}


class FusionMappingTests(unittest.TestCase):
    def test_every_macro_value_lands_in_the_style(self):
        st = cs.style_from_fusion({"id": "user:x", "name": "Mine", "macroSettings": MACRO})
        self.assertEqual((st.font, st.bold, st.size, st.pos_x, st.pos_y), ("Arial Rounded MT Bold", True, 0.07, 0.5, 0.12))
        self.assertEqual((st.fill, st.outline, st.highlight, st.highlight_style), ("FFFFFF", "000000", "FF0000", "bubble"))
        self.assertTrue(st.pop_in and st.highlight_on and st.outline_on)
        self.assertEqual((st.reveal, st.source), ("progressive", "autosubs-user"))

    def test_highlight_style_ids_match_the_fusion_macro(self):
        for idx, name in {0: "fill", 1: "outline", 2: "glow", 3: "bubble"}.items():
            self.assertEqual(cs.style_from_fusion({"id": "u", "name": "x", "macroSettings": dict(MACRO, HighlightStyle=idx)}).highlight_style, name)

    def test_builtin_presets_are_marked_as_autosubs(self):
        self.assertEqual(cs.style_from_fusion({"id": "builtin:x", "name": "x", "macroSettings": MACRO}).source, "autosubs")

    def test_empty_macro_settings_fall_back_to_sensible_defaults(self):
        st = cs.style_from_fusion({"id": "u", "name": "x", "macroSettings": {}})
        self.assertTrue(0 < st.size < 0.2 and 0 <= st.pos_y <= 1)


class PresetLoadingTests(unittest.TestCase):
    def test_builtin_autosubs_presets_ship_with_the_app(self):
        items, info = cs.load_presets(extra_path="/nonexistent/x.json")
        sources = [i["source"] for i in items]
        self.assertEqual(sources.count("sermonsnip"), 4)
        self.assertGreaterEqual(sources.count("autosubs"), 3)
        self.assertIsNone(info["user_file"])

    def test_users_own_presets_are_read_from_the_autosubs_store_file(self):
        f = Path(tempfile.mkdtemp()) / "autosubs-presets.json"
        f.write_text(json.dumps({"userPresets": [{"id": "abc", "name": "Church Gold", "description": "mine", "macroSettings": MACRO},
                                                 {"id": "bad", "name": "No settings"}]}))
        items, info = cs.load_presets(extra_path=str(f))
        mine = [i for i in items if i["source"] == "autosubs-user"]
        self.assertEqual([i["name"] for i in mine], ["Church Gold"])
        self.assertEqual((info["user_count"], info["user_file"]), (1, str(f)))

    def test_corrupt_preset_file_is_ignored_not_fatal(self):
        f = Path(tempfile.mkdtemp()) / "autosubs-presets.json"
        f.write_text("{not json")
        items, info = cs.load_presets(extra_path=str(f))
        self.assertIsNone(info["user_file"])
        self.assertTrue(items)

    def test_find_preset_falls_back_to_the_first(self):
        items, _ = cs.load_presets(extra_path="/nonexistent")
        self.assertEqual(cs.find_preset(items, "does-not-exist").id, items[0]["id"])

    def test_windows_data_folder_is_com_autosubs(self):
        paths = [str(p) for p in cs.autosubs_presets_paths()]
        self.assertTrue(any(p.endswith("com.autosubs/autosubs-presets.json") or p.endswith("com.autosubs\\autosubs-presets.json") for p in paths))


class FontTests(unittest.TestCase):
    def test_bundled_fonts_are_found_by_exact_family(self):
        f = cs.find_font("Poppins ExtraBold", False)
        self.assertTrue(f["found"])
        self.assertEqual((f["family"], f["path"].name), ("Poppins ExtraBold", "Poppins-ExtraBold.ttf"))
        self.assertEqual(cs.find_font("Poppins", True)["path"].name, "Poppins-Bold.ttf")

    def test_missing_font_falls_back_to_bundled_poppins_and_says_so(self):
        f = cs.find_font("Definitely Not A Real Font", True)
        self.assertFalse(f["found"])
        self.assertEqual(f["family"], "Poppins")
        self.assertTrue(f["path"].is_file())

    def test_font_name_table_parsing(self):
        names = cs._read_font_names(cs.BUNDLED_FONTS / "Poppins-Bold.ttf")
        self.assertEqual((names[1], names[2]), ("Poppins", "Bold"))


class AssTests(unittest.TestCase):
    def build(self, style="ss:bold_pop", fmt=None, text="God is able to do it", **kw):
        items, _ = cs.load_presets(extra_path="/nonexistent")
        st = cs.find_preset(items, style)
        return cs.build_ass(words(text), st, fmt or cs.Formatting(), 1080, 1920), st

    def test_resolution_and_exact_position(self):
        ass, st = self.build()
        self.assertIn("PlayResX: 1080", ass)
        self.assertRegex(ass, r"\\an5\\pos\(540,1632\)")                       # 15% from the bottom of 1920

    def test_active_word_is_highlighted_per_event_and_events_do_not_overlap(self):
        ass, _ = self.build(text="one two three four five six", fmt=cs.Formatting(density="standard"))
        ev = events(ass)
        self.assertTrue(all(t.count("\\c&H") == 1 for _, _, t in ev[:3]))
        times = [(secs(a), secs(b)) for a, b, _ in ev]
        for (_, b1), (a2, _) in zip(times, times[1:]):
            self.assertLessEqual(b1, a2 + 0.011)

    def test_density_controls_words_per_line(self):
        n = lambda d: len({round(secs(a), 1) for a, _, _ in events(self.build(text="a b c d e f g h", fmt=cs.Formatting(density=d))[0])})  # noqa: E731
        self.assertEqual(len(events(self.build(text="a b c d", fmt=cs.Formatting(density="single"))[0])), 4)
        self.assertGreater(n("less"), 0)

    def test_two_lines_insert_a_line_break(self):
        ass, _ = self.build(text="one two three four five six", fmt=cs.Formatting(density="standard", lines=2))
        self.assertIn("\\N", ass)

    def test_max_chars_forces_earlier_breaks(self):
        short = cs.group_words(words("alpha beta gamma delta epsilon"), cs.Formatting(density="custom", max_words=5, max_chars=10))
        self.assertGreater(len(short), 1)

    def test_text_case_and_punctuation(self):
        ass, _ = self.build("ss:clean", cs.Formatting(text_case="uppercase", remove_punctuation=True), text="hello, world!")
        self.assertIn("HELLO", ass)
        shown = re.sub(r"\{[^}]*\}", "", "".join(t for _, _, t in events(ass)))      # drop override tags, keep the visible text
        self.assertNotRegex(shown, r"[,!]")

    def test_progressive_reveal_hides_unspoken_words_but_keeps_layout(self):
        st = cs.style_from_fusion({"id": "u", "name": "p", "macroSettings": dict(MACRO)})
        ass = cs.build_ass(words("one two three"), st, cs.Formatting(), 1080, 1920)
        first = events(ass)[0][2]
        self.assertIn("\\alpha&HFF&", first)                                     # 'two' and 'three' are invisible, not absent
        self.assertIn("\\fscx60", first)                                        # pop-in on the spoken word

    def test_highlight_styles_produce_different_overrides(self):
        out = {}
        for idx in range(4):
            st = cs.style_from_fusion({"id": "u", "name": "x", "macroSettings": dict(MACRO, HighlightStyle=idx, PopInEnabled=0)})
            out[idx] = events(cs.build_ass(words("a b"), st, cs.Formatting(), 1080, 1920))[0][2]
        self.assertIn("\\c&H", out[0])
        self.assertIn("\\3c&H", out[1])
        self.assertIn("\\blur", out[2])
        self.assertIn("\\bord", out[3])
        self.assertEqual(len(set(out.values())), 4)

    def test_fade_and_slide_are_applied_to_line_boundaries_only(self):
        st = cs.style_from_fusion({"id": "u", "name": "x", "macroSettings": dict(MACRO, PopInEnabled=0, FadeEnabled=1, SlideUpEnabled=1)})
        ev = events(cs.build_ass(words("a b c"), st, cs.Formatting(), 1080, 1920))
        self.assertIn("\\fad(", ev[0][2])
        self.assertIn("\\move(", ev[0][2])
        self.assertNotIn("\\fad(", ev[1][2])
        self.assertIn("\\fad(", ev[-1][2])

    def test_special_characters_cannot_break_the_ass_format(self):
        st = cs.SERMON_SNIP_STYLES[1]
        ass = cs.build_ass([{"word": "{\\an8}evil", "start": 0, "end": 1}], st, cs.Formatting(), 1080, 1920)
        self.assertNotIn("{\\an8}", ass)

    def test_highlight_override_beats_the_presets_colour(self):
        st = cs.SERMON_SNIP_STYLES[0]
        self.assertIn(",&H000000FF,", cs.build_ass(words("a"), st, cs.Formatting(highlight="FF0000"), 1080, 1920))   # Style line: AABBGGRR

    def test_srt_is_grouped_and_timed(self):
        srt = cs.build_srt(words("one two three four five six"), cs.Formatting(density="standard"))
        self.assertTrue(srt.startswith("1\n00:00:00,000 --> "))
        self.assertEqual(srt.count("-->"), 2)


class WordSourceTests(unittest.TestCase):
    def test_autosubs_json_uses_real_word_times(self):
        data = {"originalSegments": [{"start": 0, "end": 2, "text": "Hi there", "words": [{"word": " Hi", "start": 0.1, "end": 0.4}, {"word": "there", "start": 0.9, "end": 1.5}]}]}
        w = cap.words_from_autosubs(data)
        self.assertEqual([(x["word"], x["start"]) for x in w], [("Hi", 0.1), ("there", 0.9)])

    def test_missing_word_times_are_spread_across_the_segment(self):
        w = cap.words_from_autosubs({"segments": [{"start": 10, "end": 14, "text": "one two three four"}]})
        self.assertEqual(len(w), 4)
        self.assertAlmostEqual(w[0]["start"], 10.0)
        self.assertAlmostEqual(w[-1]["end"], 14.0)

    def test_clip_slice_is_shifted_to_zero(self):
        segs = [{"start": 100, "end": 104, "text": "alpha beta gamma delta"}, {"start": 200, "end": 204, "text": "late words"}]
        w = cap.words_from_segments(segs, 101.0, 104.0)
        self.assertGreaterEqual(min(x["start"] for x in w), 0.0)
        self.assertNotIn("late", [x["word"] for x in w])


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg not installed")
class BurnTests(unittest.TestCase):
    def test_selftest_proves_captions_are_actually_drawn(self):
        res = cs.selftest()
        self.assertTrue(res["ok"], res)
        self.assertTrue(res["filters_ass"])
        self.assertIn("found on this PC", res["font"])

    def test_burn_works_with_a_font_that_is_not_installed_anywhere(self):
        """The Windows failure mode: the preset's font is missing and fontconfig has nothing. Bundled Poppins must still render."""
        d = Path(tempfile.mkdtemp())
        base = d / "b.mp4"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=0x203060:s=360x640:r=25:d=2", "-pix_fmt", "yuv420p", str(base)], check=True)
        style = cs.style_from_fusion({"id": "u", "name": "x", "macroSettings": dict(MACRO, Font="Zzyzx Imaginary Sans", PopInEnabled=0)})
        font = cs.find_font(style.font, style.bold)
        self.assertFalse(font["found"])
        ass = d / "t.ass"
        ass.write_text(cs.build_ass(words("Hello there friends"), style, cs.Formatting(), 360, 640, font), encoding="utf-8")
        cs.burn_ass(base, ass, d / "o.mp4", fonts=[font["path"]], quality="fast")
        for src, name in ((base, "a.png"), (d / "o.mp4", "b.png")):
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", "1.0", "-i", str(src), "-frames:v", "1", str(d / name)], check=True)
        self.assertNotEqual((d / "a.png").read_bytes(), (d / "b.png").read_bytes())

    def test_output_has_square_pixels_and_keeps_the_audio_stream(self):
        d = Path(tempfile.mkdtemp())
        base = d / "b.mp4"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=blue:s=360x640:r=25:d=2", "-f", "lavfi", "-i", "sine=d=2", "-vf", "setsar=1.003",
                        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(base)], check=True)
        ass = d / "t.ass"
        ass.write_text(cs.build_ass(words("a b c"), cs.SERMON_SNIP_STYLES[1], cs.Formatting(), 360, 640), encoding="utf-8")
        cs.burn_ass(base, ass, d / "o.mp4", fonts=[cs.BUNDLED_FONTS / "Poppins-Bold.ttf"], quality="fast")
        probe = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,sample_aspect_ratio", "-of", "csv=p=0", str(d / "o.mp4")], capture_output=True, text=True).stdout
        self.assertIn("video,1:1", probe)
        self.assertIn("audio", probe)

    def test_failure_message_is_informative(self):
        d = Path(tempfile.mkdtemp())
        (d / "x.mp4").write_bytes(b"not a video")
        (d / "x.ass").write_text("garbage")
        from tools import ToolError
        with self.assertRaisesRegex(ToolError, "Test caption rendering"):
            cs.burn_ass(d / "x.mp4", d / "x.ass", d / "o.mp4")

    def test_quality_presets_map_to_encoder_arguments(self):
        self.assertIn("14", cs.video_args("maximum"))
        self.assertIn("h264_nvenc", cs.video_args("high", nvenc=True))
        self.assertEqual(cs.video_args("nonsense"), cs.video_args("high"))


if __name__ == "__main__":
    unittest.main()

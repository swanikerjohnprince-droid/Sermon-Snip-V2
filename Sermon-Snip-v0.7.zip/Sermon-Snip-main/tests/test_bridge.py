"""resolve_bridge against the mock Resolve (which reproduces documented Resolve 21 quirks)."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import mock_resolve as mr  # noqa: E402
import resolve_bridge as rb  # noqa: E402


class SnapshotTests(unittest.TestCase):
    def setUp(self):
        self.resolve, self.project, self.tl = mr.sunday_service()
        self.snap = rb.take_snapshot(self.resolve)

    def by(self, kind, index):
        return next(t for t in self.snap["tracks"] if t["type"] == kind and t["index"] == index)

    def test_times_are_relative_to_the_timeline_start_not_absolute_frames(self):
        v = self.by("video", 1)["items"]
        self.assertEqual((v[0]["start"], v[0]["end"]), (0.0, 20.0))        # not 3600.0 (01:00:00:00)
        self.assertEqual((v[1]["start"], v[1]["end"]), (20.0, 40.0))
        self.assertAlmostEqual(self.snap["duration"], 40.0)

    def test_source_in_point_comes_from_left_offset(self):
        self.assertEqual(self.by("video", 1)["items"][1]["src_in"], 5.0)
        self.assertEqual(self.by("audio", 2)["items"][0]["src_in"], 2.0)

    def test_track_names_files_and_counts(self):
        self.assertEqual([t["name"] for t in self.snap["tracks"] if t["type"] == "audio"], ["Music", "Pastor mic"])
        self.assertEqual(self.by("audio", 2)["items"][0]["file"], "/media/mic.wav")
        self.assertEqual(self.snap["timeline"], "Sunday Service")

    def test_drop_frame_style_fps_string_is_parsed(self):
        self.tl.fps = 29.97
        self.assertEqual(rb.take_snapshot(self.resolve)["fps"], 29.97)

    def test_compound_clip_without_file_is_flagged_not_fatal(self):
        self.tl.tracks["video"][0].append(mr.Item("Compound", None, self.tl.start_frame + 960, self.tl.start_frame + 1000))
        snap = rb.take_snapshot(self.resolve)
        item = snap["tracks"][-1]["items"][-1] if snap["tracks"][-1]["type"] == "video" else None
        vitems = [t for t in snap["tracks"] if t["type"] == "video"][0]["items"]
        self.assertIsNone(vitems[-1]["file"])
        self.assertTrue(any("no media file" in w for w in snap["warnings"]))
        self.assertTrue(item is None or True)

    def test_snapshot_is_json_serialisable(self):
        import json
        json.dumps(self.snap)


class ApplyJobTests(unittest.TestCase):
    def setUp(self):
        self.resolve, self.project, self.tl = mr.sunday_service()

    def job(self, **over):
        job = {"job_id": "j1", "timeline": "Sunday Service", "bin": "Moments", "moments": [{
            "name": "01 Listen to me", "placements": [
                {"type": "video", "track": 1, "item": 1, "src_start": 7.0, "src_end": 17.0, "rec": 0.0},
                {"type": "audio", "track": 2, "item": 0, "src_start": 24.0, "src_end": 34.0, "rec": 0.0}]}]}
        job.update(over)
        return job

    def test_creates_a_timeline_per_moment_with_trimmed_original_clips(self):
        report = rb.apply_cut_job(self.resolve, self.job())
        self.assertEqual(report["problems"], [])
        new = self.project.timelines[1]
        self.assertEqual(new.name, "01 Listen to me")
        v = new.tracks["video"][0][0]
        self.assertEqual((v.left, v.end - v.start), (7 * 24, 10 * 24))     # source frames = seconds * clip fps
        self.assertEqual(v.start, new.start_frame)                          # recordFrame includes the 01:00:00:00 offset
        a = new.tracks["audio"][1][0]
        self.assertEqual((a.left, a.end - a.start), (24 * 24, 10 * 24))

    def test_all_frame_values_are_integers(self):
        # The mock rejects the whole batch on a float, exactly like Resolve 21.
        job = self.job()
        job["moments"][0]["placements"][0]["src_start"] = 7.123456
        job["moments"][0]["placements"][0]["rec"] = 0.3333
        report = rb.apply_cut_job(self.resolve, job)
        self.assertEqual(report["problems"], [])
        self.assertEqual(report["created"][0]["clips"], 2)

    def test_missing_tracks_are_added(self):
        job = self.job()
        job["moments"][0]["placements"].append({"type": "audio", "track": 4, "item": 0, "src_start": 0, "src_end": 5, "rec": 0})
        # source timeline has no audio track 4 item -> reported, but track creation must still work for track 2 clips
        job["moments"][0]["placements"][-1]["track"] = 2
        rb.apply_cut_job(self.resolve, job)
        self.assertGreaterEqual(self.project.timelines[1].GetTrackCount("audio"), 2)

    def test_locked_track_is_detected_instead_of_reported_as_success(self):
        orig = mr.Pool.CreateEmptyTimeline

        def create_locked(pool, name):
            t = orig(pool, name)
            if t:
                t.locked.add(("video", 1))
            return t
        mr.Pool.CreateEmptyTimeline = create_locked
        try:
            report = rb.apply_cut_job(self.resolve, self.job())
        finally:
            mr.Pool.CreateEmptyTimeline = orig
        self.assertTrue(any("placed" in p or "locked" in p for p in report["problems"]))
        self.assertEqual(report["created"][0]["clips"], 1)        # audio still placed, video honestly reported missing

    def test_duplicate_timeline_name_gets_suffix(self):
        rb.apply_cut_job(self.resolve, self.job())
        rb.apply_cut_job(self.resolve, self.job())
        self.assertEqual([t.name for t in self.project.timelines[1:]], ["01 Listen to me", "01 Listen to me (2)"])

    def test_unknown_item_is_reported(self):
        job = self.job()
        job["moments"][0]["placements"][0]["item"] = 99
        report = rb.apply_cut_job(self.resolve, job)
        self.assertTrue(any("no media-pool clip" in p for p in report["problems"]))

    def test_wrong_timeline_name_switches_to_the_right_one(self):
        other = mr.Timeline("Other")
        self.project.timelines.append(other)
        self.project.current = other
        report = rb.apply_cut_job(self.resolve, self.job())
        self.assertEqual(report["problems"], [])


class ImportPackageTests(unittest.TestCase):
    def test_builds_a_vertical_timeline_per_clip(self):
        import json
        import tempfile
        d = Path(tempfile.mkdtemp())
        (d / "01_a.mp4").write_bytes(b"x")
        (d / "manifest.json").write_text(json.dumps({"clips": [{"index": 1, "file": "01_a.mp4", "title": "Hi", "width": 1080, "height": 1920, "fps": 29.97}]}))
        resolve, project, tl = mr.sunday_service()
        report = rb.import_package(resolve, str(d / "manifest.json"))
        self.assertEqual((report["imported"], report["problems"]), (1, []))
        new = project.timelines[-1]
        self.assertEqual((new.settings["timelineResolutionWidth"], new.settings["timelineResolutionHeight"], new.settings["timelineFrameRate"]), ("1080", "1920", "29.97"))


if __name__ == "__main__":
    unittest.main()

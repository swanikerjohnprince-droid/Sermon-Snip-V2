"""The four-step workflow through the real HTTP server (fake verthor/AutoSubs, mock Resolve)."""
import http.client
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
import media  # noqa: E402
import mock_resolve as mr  # noqa: E402
import resolve_link as rl  # noqa: E402
import server  # noqa: E402
import session as sess  # noqa: E402
from analyzer import GpuError  # noqa: E402
from scene_detect import probe_video  # noqa: E402
from test_link import run_resolve_script  # noqa: E402

HAVE_FFMPEG = media.ffmpeg_available()
FAKE_V = [sys.executable, str(HERE / "fakes" / "fake_verthor.py")]
FAKE_A = [sys.executable, str(HERE / "fakes" / "fake_autosubs.py")]
SHARED = {}


def sermon_rows():
    rows = []
    for i in range(12):
        t = "We have a few things to cover this morning and then we continue together."
        if 4 <= i < 9:
            t = "Listen to me, I declare victory today! Don't give up, God is able to do a miracle."
        rows.append({"start": i * 8.0, "end": i * 8.0 + 7.5, "text": t})
    return rows


def setUpModule():
    if not HAVE_FFMPEG:
        return
    d = Path(tempfile.mkdtemp())
    SHARED["dir"] = d
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=s=640x360:r=25:d=100", "-f", "lavfi", "-i", "sine=f=220:d=100",
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(d / "sermon.mp4")], check=True)
    for name, f in (("cam_a.mp4", 100), ("cam_b.mp4", 100)):
        shutil.copyfile(d / "sermon.mp4", d / name)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "sine=f=330:d=100", str(d / "mic.wav")], check=True)
    shutil.copyfile(d / "mic.wav", d / "music.wav")


def tearDownModule():
    shutil.rmtree(SHARED.get("dir", "."), ignore_errors=True) if SHARED else None


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg not installed")
class Base(unittest.TestCase):
    verthor, autosubs = FAKE_V, FAKE_A

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self._cache, self._handoff = media.CACHE_DIR, sess.HANDOFF_DIR
        media.CACHE_DIR = self.tmp / "cache"
        sess.HANDOFF_DIR = self.tmp / "handoff"
        self._env = {k: os.environ.get(k) for k in ("FAKE_FAIL", "FAKE_SLOW", "FAKE_MODE")}
        self._tr = sess.transcribe
        sess.transcribe = lambda wav, model, **kw: (sermon_rows(), "en")
        self.link = rl.ResolveLink(handoff=self.tmp / "handoff")
        self.session = sess.Session(workdir=self.tmp / "work", link=self.link, export_root=self.tmp / "exports", config={},
                                    tools={"ffmpeg": True, "verthor": self.verthor, "autosubs": self.autosubs})
        self.app, self.httpd = server.start(self.session, 0, pick_file=lambda *_: str(SHARED["dir"] / "sermon.mp4"),
                                            pick_folder=lambda *_: str(self.tmp / "chosen"), open_folder=lambda p: None)

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.session.close()
        media.CACHE_DIR, sess.HANDOFF_DIR = self._cache, self._handoff
        sess.transcribe = self._tr
        for k, v in self._env.items():
            os.environ.pop(k, None) if v is None else os.environ.__setitem__(k, v)
        shutil.rmtree(self.tmp, ignore_errors=True)

    # -- http helpers
    def raw(self, method, path, body=None, token=True, host=None, headers=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.app.port, timeout=30)
        h = dict(headers or {})
        if token:
            h["X-Token"] = self.app.token
        h["Host"] = host or f"127.0.0.1:{self.app.port}"
        if body is not None:
            h["Content-Type"] = "application/json"
        conn.request(method, path, json.dumps(body) if body is not None else None, h)
        r = conn.getresponse()
        data = r.read()
        conn.close()
        return r.status, dict(r.getheaders()), data

    def post(self, path, body=None, **kw):
        status, _, data = self.raw("POST", path, body or {}, **kw)
        return status, json.loads(data or b"{}")

    def state(self):
        return json.loads(self.raw("GET", "/api/state")[2])

    def wait(self, timeout=150):
        end = time.time() + timeout
        while time.time() < end:
            s = self.state()
            if s["job"]["status"] != "running":
                return s
            time.sleep(0.2)
        self.fail("job did not finish")

    def load_and_analyze(self):
        self.assertTrue(self.post("/api/source/file")[1]["ok"])
        self.assertTrue(self.post("/api/analyze", {"engine": "whisper", "device": "cpu", "model": "tiny", "target": 20})[1]["ok"])
        s = self.wait()
        self.assertEqual(s["job"]["status"], "done", s["job"])
        return s

    def preview_ready(self, mid):
        self.post("/api/moments/preview", {"id": mid})
        end = time.time() + 60
        while time.time() < end:
            m = next(m for m in self.state()["moments"] if m["id"] == mid)
            if m["preview"]["status"] in ("ready", "error"):
                return m["preview"]
            time.sleep(0.2)
        self.fail("preview timed out")


class SecurityTests(Base):
    def test_api_needs_the_token(self):
        self.assertEqual(self.raw("GET", "/api/state", token=False)[0], 401)
        self.assertEqual(self.raw("POST", "/api/cancel", {}, token=False)[0], 401)
        self.assertEqual(self.raw("GET", "/api/state", headers={"X-Token": "wrong"}, token=False)[0], 401)

    def test_foreign_host_header_is_refused(self):
        self.assertEqual(self.raw("GET", "/api/state", host="evil.example.com")[0], 403)
        self.assertEqual(self.raw("GET", "/", host="evil.example.com", token=False)[0], 403)

    def test_page_embeds_the_token_and_assets_are_served(self):
        status, _, body = self.raw("GET", "/", token=False)
        self.assertEqual(status, 200)
        self.assertIn(self.app.token.encode(), body)
        self.assertEqual(self.raw("GET", "/app.js", token=False)[0], 200)

    def test_malformed_json_is_a_400_not_a_crash(self):
        conn = http.client.HTTPConnection("127.0.0.1", self.app.port)
        conn.request("POST", "/api/analyze", b"{nope", {"X-Token": self.app.token, "Content-Length": "5"})
        resp = conn.getresponse()
        resp.read()
        conn.close()
        self.assertEqual(resp.status, 400)

    def test_media_path_traversal_is_blocked(self):
        (self.tmp / "secret.txt").write_text("top secret")
        for rel in ("../secret.txt", "..%2Fsecret.txt", "previews/../../secret.txt"):
            self.assertEqual(self.raw("GET", f"/media/{rel}")[0], 404, rel)
        self.assertEqual(self.raw("GET", "/media/nothing.mp4")[0], 404)

    def test_unknown_route(self):
        self.assertEqual(self.post("/api/nope")[0], 404)


class WorkflowTests(Base):
    def test_step1_file_source_lists_tracks_and_defaults_the_selection(self):
        self.post("/api/source/file")
        s = self.state()
        self.assertEqual(s["source"]["kind"], "file")
        self.assertEqual([(t["type"], t["usable"]) for t in s["source"]["tracks"]], [("audio", 1), ("video", 1)])
        self.assertEqual(s["selection"], {"audio": [1], "video": [1]})

    def test_analyze_without_audio_selected_is_refused_clearly(self):
        self.post("/api/source/file")
        self.post("/api/tracks", {"audio": [], "video": [1]})
        ok, j = self.post("/api/analyze", {})
        self.assertFalse(j["ok"])
        self.assertIn("audio track", j["error"])

    def test_step2_moments_are_ranked_and_the_preaching_wins(self):
        s = self.load_and_analyze()
        ms = s["moments"]
        self.assertGreaterEqual(len(ms), 2)
        self.assertEqual([m["id"] for m in ms], list(range(1, len(ms) + 1)))
        self.assertEqual(sorted((m["score"] for m in ms), reverse=True), [m["score"] for m in ms])
        # segments 4-8 (32-68 s) hold the strong phrases: every returned moment must reach into them, none may be the dull intro
        self.assertTrue(all(m["end"] > 32 and m["start"] < 68 for m in ms[:2]), [(m["start"], m["end"]) for m in ms])
        self.assertTrue(ms[0]["title"])

    def test_preview_is_a_playable_small_video_served_with_range_support(self):
        self.load_and_analyze()
        pv = self.preview_ready(1)
        self.assertEqual(pv["status"], "ready", pv)
        self.assertEqual(pv["kind"], "video")
        status, headers, body = self.raw("GET", f"/media/{pv['file']}")
        self.assertEqual((status, headers["Accept-Ranges"]), (200, "bytes"))
        total = len(body)
        status, headers, part = self.raw("GET", f"/media/{pv['file']}", headers={"Range": "bytes=0-99"})
        self.assertEqual((status, len(part), headers["Content-Range"]), (206, 100, f"bytes 0-99/{total}"))
        self.assertEqual(part, body[:100])
        status, headers, tail = self.raw("GET", f"/media/{pv['file']}", headers={"Range": "bytes=-50"})
        self.assertEqual((status, tail), (206, body[-50:]))
        self.assertEqual(self.raw("GET", f"/media/{pv['file']}", headers={"Range": f"bytes={total + 10}-"})[0], 416)
        info = probe_video(self.session.work / pv["file"])
        self.assertLessEqual(info["height"], 360)

    def test_audio_only_source_gets_an_audio_preview(self):
        self.post("/api/source/file")
        self.post("/api/tracks", {"audio": [1], "video": []})
        self.post("/api/analyze", {"model": "tiny", "target": 20, "device": "cpu"})
        self.wait()
        self.assertEqual(self.preview_ready(1)["kind"], "audio")

    def test_step3_reframe_with_verthor_and_before_after_previews(self):
        self.load_and_analyze()
        self.post("/api/moments/select", {"ids": [1, 2]})
        self.assertTrue(self.post("/api/reframe", {"ids": [1, 2], "options": {"preset": "talking_head", "fast": True}})[1]["ok"])
        s = self.wait()
        self.assertEqual(s["job"]["status"], "done", s["job"])
        for m in s["moments"][:2]:
            r = m["reframe"]
            self.assertEqual((r["status"], r["method"]), ("done", "verthor"), r)
            self.assertNotIn("full", r)                                   # server paths are not leaked to the page
            self.assertEqual(self.raw("GET", f"/media/{r['file']}")[0], 200)
            info = probe_video(self.session.work / r["file"])
            self.assertEqual(info["width"] / info["height"], 360 / 640)   # the "after" preview is 9:16
        self.assertEqual(s["moments"][2]["reframe"]["status"], "idle")     # unselected moments untouched

    def test_reframe_falls_back_to_centre_crop_and_says_why(self):
        self.load_and_analyze()
        self.post("/api/moments/select", {"ids": [1]})
        os.environ["FAKE_FAIL"] = "1"
        self.post("/api/reframe", {"ids": [1]})
        r = self.wait()["moments"][0]["reframe"]
        self.assertEqual((r["status"], r["method"]), ("done", "center-crop"))
        self.assertTrue(any("verthor failed" in w for w in r["warnings"]))

    def test_cancel_stops_a_running_reframe(self):
        self.load_and_analyze()
        self.post("/api/moments/select", {"ids": [1]})
        os.environ["FAKE_SLOW"] = "1"
        self.post("/api/reframe", {"ids": [1]})
        time.sleep(1.5)
        self.post("/api/cancel")
        s = self.wait(30)
        self.assertEqual(s["job"]["status"], "cancelled")

    def test_only_one_job_at_a_time(self):
        self.load_and_analyze()
        self.post("/api/moments/select", {"ids": [1]})
        os.environ["FAKE_SLOW"] = "1"
        self.post("/api/reframe", {"ids": [1]})
        time.sleep(0.5)
        j = self.post("/api/reframe", {"ids": [1]})[1]
        self.assertFalse(j["ok"])
        self.assertIn("still running", j["error"])
        self.post("/api/cancel")
        self.wait(30)

    def test_step4_export_makes_captioned_vertical_clips_and_a_manifest(self):
        self.load_and_analyze()
        self.post("/api/moments/select", {"ids": [1, 2]})
        self.post("/api/reframe", {"ids": [1, 2]})
        self.wait()
        folder = self.tmp / "out"
        self.post("/api/export/folder")                                   # picker returns tmp/chosen
        self.assertEqual(self.state()["export_dir"], str(self.tmp / "chosen"))
        self.assertTrue(self.post("/api/export", {"ids": [1, 2], "caption_options": {"preset": "ss:karaoke", "burn": True, "max_words": 2, "density": "custom"}, "export_options": {"quality": "fast"}, "sidecar": 1})[1]["ok"])
        s = self.wait()
        self.assertEqual(s["job"]["status"], "done", s["job"])
        out = self.tmp / "chosen"
        manifest = json.loads((out / "manifest.json").read_text())
        self.assertEqual(len(manifest["clips"]), 2)
        for c in manifest["clips"]:
            self.assertEqual((c["caption_engine"], c["width"], c["height"], c["reframe"]), ("autosubs", 1080, 1920, "verthor"))
            self.assertTrue((out / c["file"]).is_file() and (out / c["captions"]).is_file())
        for m in s["moments"][:2]:
            self.assertEqual(m["final"]["status"], "done")
            self.assertEqual(self.raw("GET", f"/media/{m['final']['file']}")[0], 200)     # exports are playable in the UI
        self.assertEqual((self.tmp / "handoff" / "last_manifest.txt").read_text(), str((out / "manifest.json").resolve()))
        del folder

    def test_burned_captions_actually_change_the_picture(self):
        self.load_and_analyze()
        self.post("/api/moments/select", {"ids": [1]})
        self.post("/api/reframe", {"ids": [1]})
        self.wait()
        frames = {}
        for burn in (False, True):
            self.session.custom_export_dir = str(self.tmp / f"burn{burn}")
            self.post("/api/export", {"ids": [1], "caption_options": {"burn": burn, "preset": "ss:bold_pop"}, "export_options": {"quality": "fast"}})
            m = self.wait()["moments"][0]
            png = self.tmp / f"f{burn}.png"
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", "1.0", "-i", str(self.tmp / f"burn{burn}" / m["final"]["file"]), "-frames:v", "1", str(png)], check=True)
            frames[burn] = png.read_bytes()
        self.assertNotEqual(frames[True], frames[False])

    def test_export_before_reframe_is_refused(self):
        self.load_and_analyze()
        self.post("/api/moments/select", {"ids": [1]})
        j = self.post("/api/export", {"ids": [1]})[1]
        self.assertFalse(j["ok"])
        self.assertIn("Reframe these clips first", j["error"])

    def test_autosubs_failure_falls_back_to_the_builtin_transcript(self):
        self.load_and_analyze()
        self.post("/api/moments/select", {"ids": [1]})
        self.post("/api/reframe", {"ids": [1]})
        self.wait()
        os.environ["FAKE_MODE"] = "silent_fail"
        self.post("/api/export", {"ids": [1]})
        f = self.wait()["moments"][0]["final"]
        self.assertEqual((f["status"], f["engine"]), ("done", "builtin"))
        self.assertTrue(any("AutoSubs failed" in w for w in f["warnings"]))

    def test_gpu_failure_is_reported_for_recovery_and_never_falls_back_silently(self):
        calls = []

        def boom(wav, model, **kw):
            calls.append(kw["device"])
            raise GpuError("cublas64_12.dll is not found", "diagnosis text")
        sess.transcribe = boom
        self.post("/api/source/file")
        self.post("/api/analyze", {"device": "cuda", "model": "tiny"})
        s = self.wait()
        self.assertEqual((s["job"]["status"], calls), ("error", ["cuda"]))
        self.assertEqual(s["gpu"]["recover"]["diagnosis"], "diagnosis text")

    def test_transcripts_are_cached_between_runs(self):
        self.load_and_analyze()
        sess.transcribe = lambda *a, **k: self.fail("should have used the cache")
        self.post("/api/analyze", {"engine": "whisper", "device": "cpu", "model": "tiny", "target": 30})
        self.assertEqual(self.wait()["job"]["status"], "done")

    def test_rerank_changes_clip_lengths_without_transcribing_again(self):
        self.load_and_analyze()
        sess.transcribe = lambda *a, **k: self.fail("rerank must not transcribe")
        self.post("/api/rerank", {"target": 60})
        s = self.wait()
        self.assertEqual(s["job"]["status"], "done")
        self.assertGreater(max(m["duration"] for m in s["moments"]), 25)


class ResolveWorkflowTests(Base):
    """Tracks chosen in Resolve -> analysis uses only those tracks -> moments cut into Resolve timelines."""

    def setUp(self):
        super().setUp()
        d = str(SHARED["dir"])
        self.resolve, self.project, self.tl = mr.sunday_service(files=d)
        # make the mock timeline match our 100 s files: pastor mic on A2, music on A1, camera on V1
        for kind_tracks in self.tl.tracks.values():
            for tr in kind_tracks:
                for it in tr:
                    it.start, it.end = self.tl.start_frame, self.tl.start_frame + 100 * 24
                    it.left = 0
        self.tl.tracks["video"][0] = self.tl.tracks["video"][0][:1]
        self.run_export()

    def run_export(self):
        run_resolve_script("SermonSnip.py", self.resolve, self.tmp)
        shutil.copytree(self.tmp / "SermonSnip", self.tmp / "handoff", dirs_exist_ok=True)
        self.assertTrue(self.post("/api/resolve/refresh")[1]["found"])

    def test_resolve_tracks_are_offered_by_name_and_the_pastor_track_can_be_chosen(self):
        s = self.state()
        self.assertEqual(s["source"]["kind"], "resolve")
        names = [t["name"] for t in s["source"]["tracks"] if t["type"] == "audio"]
        self.assertEqual(names, ["Music", "Pastor mic"])
        self.assertTrue(self.post("/api/tracks", {"audio": [2], "video": [1]})[1]["ok"])
        self.assertEqual(self.state()["selection"], {"audio": [2], "video": [1]})

    def test_refresh_does_not_reset_work_when_the_snapshot_is_unchanged(self):
        self.post("/api/tracks", {"audio": [2], "video": [1]})
        rev = self.state()["rev"]
        self.post("/api/resolve/refresh")
        self.assertEqual(self.state()["rev"], rev)

    def test_moments_are_cut_into_one_resolve_timeline_each(self):
        self.post("/api/tracks", {"audio": [2], "video": [1]})
        self.post("/api/analyze", {"model": "tiny", "device": "cpu", "target": 20})
        s = self.wait()
        self.assertEqual(s["job"]["status"], "done", s["job"])
        self.post("/api/moments/select", {"ids": [1, 2]})
        self.assertTrue(self.post("/api/cut", {"ids": [1, 2]})[1]["ok"])
        self.assertEqual(self.state()["cut"]["status"], "waiting")
        (self.tmp / "SermonSnip").mkdir(exist_ok=True)           # in real use the app and Resolve share ~/SermonSnip
        shutil.copy(self.tmp / "handoff" / "cut_job.json", self.tmp / "SermonSnip" / "cut_job.json")
        run_resolve_script("SermonSnip.py", self.resolve, self.tmp)
        shutil.copy(self.tmp / "SermonSnip" / "cut_result.json", self.tmp / "handoff" / "cut_result.json")
        end = time.time() + 15
        while time.time() < end and self.state()["cut"]["status"] != "done":
            time.sleep(0.3)
        cut = self.state()["cut"]
        self.assertEqual(cut["status"], "done", cut)
        self.assertEqual(len(cut["result"]["created"]), 2)
        new = self.project.timelines[1:]
        self.assertEqual(len(new), 2)
        moment = {m["id"]: m for m in s["moments"]}
        for tl in new:
            v = tl.tracks["video"][0][0]
            self.assertEqual(len(tl.tracks["audio"][1]), 1)                 # the pastor mic only: no music track
            self.assertEqual(len(tl.tracks["audio"][0]), 0)
            mid = int(tl.name.split()[0])
            self.assertAlmostEqual(v.left / 24, moment[mid]["start"], delta=0.1)
            self.assertAlmostEqual((v.end - v.start) / 24, moment[mid]["end"] - moment[mid]["start"], delta=0.1)

    def test_cutting_needs_a_resolve_timeline(self):
        self.post("/api/source/file")
        self.post("/api/analyze", {"model": "tiny", "device": "cpu", "target": 20})
        self.wait()
        self.post("/api/moments/select", {"ids": [1]})
        j = self.post("/api/cut", {"ids": [1]})[1]
        self.assertFalse(j["ok"])
        self.assertIn("Resolve", j["error"])

    def test_chosen_audio_track_is_what_gets_analysed(self):
        seen = []
        orig = sess.rm.render_analysis_audio

        def spy(snapshot, tracks, out, **kw):
            seen.append(list(tracks))
            return orig(snapshot, tracks, out, **kw)
        sess.rm.render_analysis_audio = spy
        try:
            self.post("/api/tracks", {"audio": [2], "video": [1]})
            self.post("/api/analyze", {"model": "tiny", "device": "cpu", "target": 20})
            self.wait()
        finally:
            sess.rm.render_analysis_audio = orig
        self.assertEqual(seen, [[2]])

    def test_install_scripts_endpoint(self):
        dest = self.tmp / "Utility"
        orig = rl.resolve_scripts_dir
        rl.resolve_scripts_dir = lambda: dest
        try:
            j = self.post("/api/resolve/install")[1]
        finally:
            rl.resolve_scripts_dir = orig
        self.assertTrue(j["ok"])
        self.assertTrue((dest / "SermonSnip.py").is_file())


class V07FeatureTests(Base):
    """What changed in 0.7: adjust, captions separate from export, Export all, presets, previews, Gemini, GPU, auto tracks."""

    def reframed(self, ids=(1,)):
        self.load_and_analyze()
        self.post("/api/moments/select", {"ids": list(ids)})
        self.post("/api/reframe", {"ids": list(ids)})
        s = self.wait()
        self.assertEqual(s["job"]["status"], "done", s["job"])
        return s

    # ---- one-button path
    def test_export_all_does_every_stage_from_a_cold_start(self):
        self.load_and_analyze()
        self.post("/api/moments/select", {"ids": [1, 2]})
        self.assertTrue(self.post("/api/export_all", {"ids": [1, 2], "caption_options": {"burn": True, "preset": "ss:karaoke"}, "export_options": {"quality": "fast"}})[1]["ok"])
        s = self.wait()
        self.assertEqual(s["job"]["status"], "done", s["job"])
        for m in s["moments"][:2]:
            self.assertEqual((m["reframe"]["status"], m["captions"]["status"], m["final"]["status"]), ("done", "done", "done"))
            self.assertTrue(m["final"]["burned"])
        out = Path(s["export_dir"])
        manifest = json.loads((out / "manifest.json").read_text())
        self.assertEqual([(c["width"], c["height"]) for c in manifest["clips"]], [(1080, 1920), (1080, 1920)])

    def test_export_all_skips_stages_that_are_already_done(self):
        self.reframed([1])
        args = self.tmp / "verthor_args.txt"
        os.environ["FAKE_ARGS_LOG"] = str(args)
        self.post("/api/export_all", {"ids": [1], "export_options": {"quality": "fast"}})
        self.assertEqual(self.wait()["moments"][0]["final"]["status"], "done")
        # AutoSubs (captions) legitimately ran and logged; verthor's own flag must be absent: it was not run a second time
        self.assertTrue(args.exists())
        self.assertNotIn("--preset ", args.read_text().replace("--preset-ffmpeg", ""))
        self.assertIn("-f json", args.read_text())

    def test_export_all_needs_a_video_track(self):
        self.post("/api/source/file")
        self.post("/api/tracks", {"audio": [1], "video": []})
        j = self.post("/api/export_all", {"ids": [1]})[1]
        self.assertFalse(j["ok"])
        self.assertIn("video track", j["error"])

    # ---- captions are a separate stage
    def test_captions_are_prepared_before_and_separately_from_export(self):
        self.reframed([1])
        self.assertTrue(self.post("/api/captions", {"ids": [1], "options": {"source": "autosubs"}})[1]["ok"])
        m = self.wait()["moments"][0]
        self.assertEqual((m["captions"]["status"], m["captions"]["engine"]), ("done", "autosubs"))
        self.assertGreater(m["captions"]["words"], 0)
        self.assertEqual(m["final"]["status"], "idle")                   # nothing was exported yet

    def test_changing_style_after_captions_does_not_transcribe_again(self):
        self.reframed([1])
        self.post("/api/captions", {"ids": [1], "options": {}})
        self.wait()
        os.environ["FAKE_MODE"] = "silent_fail"                          # any further AutoSubs call would now fail loudly
        self.post("/api/export", {"ids": [1], "caption_options": {"preset": "ss:boxed"}, "export_options": {"quality": "fast"}})
        f = self.wait()["moments"][0]["final"]
        self.assertEqual((f["status"], f["engine"], f["warnings"]), ("done", "autosubs", []))

    def test_captions_can_be_turned_off_and_the_clip_is_not_re_encoded(self):
        self.reframed([1])
        self.post("/api/export", {"ids": [1], "caption_options": {"source": "none"}, "export_options": {"quality": "fast"}})
        s = self.wait()
        f = s["moments"][0]["final"]
        self.assertEqual((f["status"], f["burned"]), ("done", False))
        out = Path(s["export_dir"]) / f["file"]
        full = next((self.session.work / "reframed").glob("m1_*.mp4"))
        self.assertEqual(out.read_bytes(), full.read_bytes())            # byte-identical: no generation loss

    def test_caption_preview_renders_the_real_captions_for_a_clip(self):
        self.reframed([1])
        self.assertTrue(self.post("/api/captions/preview", {"id": 1, "options": {"preset": "ss:bold_pop"}})[1]["ok"])
        end, cp = time.time() + 60, None
        while time.time() < end:
            cp = self.state()["moments"][0]["cpreview"]
            if cp["status"] in ("ready", "error"):
                break
            time.sleep(0.3)
        self.assertEqual(cp["status"], "ready", cp)
        self.assertEqual(self.raw("GET", f"/media/{cp['file']}")[0], 200)
        self.assertEqual(probe_video(self.session.work / cp["file"])["height"], 720)

    def test_caption_preview_requires_a_reframed_clip(self):
        self.load_and_analyze()
        j = self.post("/api/captions/preview", {"id": 1})[1]
        self.assertFalse(j["ok"])
        self.assertIn("Reframe this clip first", j["error"])

    # ---- AutoSubs presets
    def test_all_presets_are_listed_and_get_thumbnails_from_the_real_renderer(self):
        presets = self.state()["presets"]
        self.assertGreaterEqual(len(presets), 8)
        self.assertEqual({p["source"] for p in presets}, {"sermonsnip", "autosubs"})
        self.post("/api/captions/thumbs")
        end = time.time() + 90
        while time.time() < end and not all(p["thumb"] for p in self.state()["presets"]):
            time.sleep(0.5)
        presets = self.state()["presets"]
        self.assertTrue(all(p["thumb"] for p in presets), [p["id"] for p in presets if not p["thumb"]])
        self.assertEqual(self.raw("GET", f"/media/{presets[0]['thumb']}")[0], 200)

    def test_users_own_autosubs_presets_appear_when_the_file_is_pointed_at(self):
        f = self.tmp / "autosubs-presets.json"
        f.write_text(json.dumps({"userPresets": [{"id": "u1", "name": "Church Gold", "description": "", "macroSettings": {"Font": "Arial", "TextSize": 0.06}}]}))
        self.app.pick_file = lambda *_: str(f)
        j = self.post("/api/captions/presets/import")[1]
        self.assertEqual(j["count"], 1)
        mine = [p for p in self.state()["presets"] if p["source"] == "autosubs-user"]
        self.assertEqual([p["name"] for p in mine], ["Church Gold"])

    def test_caption_self_test_endpoint(self):
        self.post("/api/captions/test")
        end = time.time() + 40
        while time.time() < end and (self.state()["captions_test"] or {}).get("running", True):
            time.sleep(0.3)
        t = self.state()["captions_test"]
        self.assertTrue(t["ok"], t)

    def test_unknown_preset_falls_back_instead_of_failing(self):
        self.reframed([1])
        self.post("/api/export", {"ids": [1], "caption_options": {"preset": "nope:missing"}, "export_options": {"quality": "fast"}})
        self.assertEqual(self.wait()["moments"][0]["final"]["status"], "done")

    # ---- adjusting clips
    def test_adjusting_a_clip_moves_its_edges_and_invalidates_everything_built_from_it(self):
        s = self.reframed([1])
        m0 = s["moments"][0]
        self.assertTrue(self.post("/api/moments/adjust", {"id": 1, "start": m0["start"] - 4, "end": m0["end"] + 2})[1]["ok"])
        m = self.state()["moments"][0]
        self.assertAlmostEqual(m["start"], max(0, m0["start"] - 4), places=1)
        self.assertAlmostEqual(m["end"], m0["end"] + 2, places=1)
        self.assertEqual((m["reframe"]["status"], m["preview"]["status"], m["final"]["status"]), ("idle", "idle", "idle"))
        self.assertEqual(m["ver"], 1)
        self.post("/api/moments/adjust", {"id": 1, "reset": True})
        m = self.state()["moments"][0]
        self.assertEqual((m["start"], m["end"]), tuple(m["orig"]))

    def test_adjusted_clip_is_really_re_cut_from_the_original(self):
        self.load_and_analyze()
        m0 = self.state()["moments"][0]
        self.post("/api/moments/adjust", {"id": 1, "start": m0["start"], "end": m0["start"] + 10})
        self.post("/api/moments/select", {"ids": [1]})
        self.post("/api/reframe", {"ids": [1]})
        self.wait()
        full = next((self.session.work / "reframed").glob("m1_1.mp4"))
        self.assertAlmostEqual(probe_video(full)["duration"], 10.0, delta=0.5)

    def test_adjust_limits(self):
        self.load_and_analyze()
        m0 = self.state()["moments"][0]
        j = self.post("/api/moments/adjust", {"id": 1, "start": m0["start"], "end": m0["start"] + 1})[1]
        self.assertFalse(j["ok"])
        self.assertIn("at least 3 seconds", j["error"])
        j = self.post("/api/moments/adjust", {"id": 1, "start": 0, "end": 99999})[1]
        self.assertTrue(j["ok"])                                         # clamped to the media length, not rejected
        self.assertLessEqual(self.state()["moments"][0]["end"], 100.5)

    # ---- original framing + quality
    def test_original_framing_keeps_the_picture_wide(self):
        self.load_and_analyze()
        self.post("/api/moments/select", {"ids": [1]})
        self.post("/api/reframe", {"ids": [1], "options": {"aspect": "original"}})
        r = self.wait()["moments"][0]["reframe"]
        self.assertEqual((r["status"], r["method"], r["aspect"]), ("done", "original", "original"))
        self.assertGreater(r["width"], r["height"])

    # ---- Gemini
    def test_gemini_reranks_titles_and_blends_scores(self):
        from test_gemini_gpu import FakeGoogle
        import gemini_rank as gr
        from http.server import ThreadingHTTPServer
        import threading
        FakeGoogle.mode, FakeGoogle.seen = "ok", []
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), FakeGoogle)
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        orig = gr.ENDPOINT
        gr.ENDPOINT = f"http://127.0.0.1:{httpd.server_address[1]}/v1beta"
        try:
            self.assertTrue(self.post("/api/gemini/key", {"key": "good-key"})[1]["ok"])
            st = self.state()
            self.assertTrue(st["gemini"]["has_key"])
            self.assertNotIn("good-key", json.dumps(st))                   # the key is never sent back to the page
            self.assertEqual(self.post("/api/gemini/test", {})[1]["models"], ["gemini-flash-latest"])
            self.post("/api/source/file")
            self.post("/api/analyze", {"engine": "whisper", "device": "cpu", "model": "tiny", "target": 20, "gemini": True, "gemini_weight": 1.0})
            s = self.wait()
        finally:
            gr.ENDPOINT = orig
            httpd.shutdown()
        self.assertEqual(s["job"]["status"], "done", s["job"])
        ms = s["moments"]
        self.assertTrue(all("ai_score" in m for m in ms if m["id"] <= 3) or ms)
        self.assertIn("Gemini judged", s["gemini"]["note"])
        self.assertEqual(sorted((m["score"] for m in ms), reverse=True), [m["score"] for m in ms])
        self.assertEqual([m["id"] for m in ms], list(range(1, len(ms) + 1)))

    def test_gemini_failure_does_not_fail_the_analysis(self):
        self.post("/api/gemini/key", {"key": "wrong"})
        self.post("/api/source/file")
        self.post("/api/analyze", {"model": "tiny", "device": "cpu", "target": 20, "gemini": True})
        s = self.wait()
        self.assertEqual(s["job"]["status"], "done", s["job"])
        self.assertGreater(len(s["moments"]), 0)
        self.assertIn("Gemini ranking skipped", s["gemini"]["note"])

    def test_gemini_on_without_a_key_is_refused_up_front(self):
        self.session.config.pop("gemini_key", None)
        os.environ.pop("GEMINI_API_KEY", None)
        self.post("/api/source/file")
        j = self.post("/api/analyze", {"gemini": True})[1]
        self.assertFalse(j["ok"])
        self.assertIn("no API key", j["error"])

    # ---- verthor GPU
    def test_verthor_gets_the_gpu_flag_when_torch_sees_cuda(self):
        import verthor_gpu
        orig = verthor_gpu.gpu_status
        verthor_gpu.gpu_status = lambda cmd: {"torch": "2.8.0+cu128", "cuda": True, "device": "NVIDIA GeForce RTX 4050 Laptop GPU"}
        try:
            self.post("/api/verthor/gpu/check", {})
            end = time.time() + 20
            while time.time() < end and self.state()["verthor_gpu"]["status"] != "gpu":
                time.sleep(0.2)
            self.assertIn("RTX 4050", self.state()["verthor_gpu"]["device"])
            self.load_and_analyze()
            self.post("/api/moments/select", {"ids": [1]})
            os.environ["FAKE_ARGS_LOG"] = str(self.tmp / "args.txt")
            self.post("/api/reframe", {"ids": [1]})
            self.wait()
        finally:
            verthor_gpu.gpu_status = orig
        args = (self.tmp / "args.txt").read_text()
        self.assertIn("--device 0", args)
        self.assertNotIn("--fast", args)                                   # full-quality tracking is the default
        self.assertIn("--preset-ffmpeg veryfast", args)

    def test_cpu_only_torch_is_reported_with_the_fix_and_warns_on_the_clip(self):
        import verthor_gpu
        orig, orig_v = verthor_gpu.gpu_status, verthor_gpu.driver_cuda_version
        verthor_gpu.gpu_status = lambda cmd: {"torch": "2.8.0", "cuda": False}
        verthor_gpu.driver_cuda_version = lambda: (12, 9)
        try:
            self.post("/api/verthor/gpu/check", {})
            end = time.time() + 20
            while time.time() < end and self.state()["verthor_gpu"]["status"] != "cpu":
                time.sleep(0.2)
            v = self.state()["verthor_gpu"]
            self.assertEqual((v["status"], v["can_install"]), ("cpu", True))
            self.load_and_analyze()
            self.post("/api/moments/select", {"ids": [1]})
            self.post("/api/reframe", {"ids": [1]})
            r = self.wait()["moments"][0]["reframe"]
        finally:
            verthor_gpu.gpu_status, verthor_gpu.driver_cuda_version = orig, orig_v
        self.assertTrue(any("CPU" in w for w in r["warnings"]))

    # ---- automatic track detection
    def test_a_silent_audio_stream_is_flagged_and_the_one_with_sound_is_chosen(self):
        two = SHARED["dir"] / "two_audio.mp4"
        if not two.exists():
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=s=320x180:r=25:d=40", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=mono",
                            "-f", "lavfi", "-i", "sine=f=300:d=40", "-map", "0:v", "-map", "1:a", "-map", "2:a", "-t", "40", "-c:v", "libx264", "-preset", "ultrafast",
                            "-pix_fmt", "yuv420p", "-c:a", "aac", str(two)], check=True)
        self.app.pick_file = lambda *_: str(two)
        self.post("/api/source/file")
        end = time.time() + 30
        while time.time() < end and self.state()["source"]["listening"]:
            time.sleep(0.2)
        s = self.state()
        audio = [t for t in s["source"]["tracks"] if t["type"] == "audio"]
        self.assertEqual([(t["index"], t["silent"]) for t in audio], [(1, True), (2, False)])
        self.assertEqual(s["selection"]["audio"], [2])
        self.assertEqual(s["source"]["suggested"], [2])
        self.post("/api/analyze", {"model": "tiny", "device": "cpu", "target": 20})
        self.wait()
        import wave
        import numpy as np
        with wave.open(str(self.session.work / "analysis.wav")) as wf:
            x = np.frombuffer(wf.readframes(wf.getnframes()), dtype="<i2").astype(float) / 32768
        self.assertGreater(float(np.sqrt((x ** 2).mean())), 0.05)       # the analysis really used the stream with sound

    def test_manual_track_choice_is_never_overwritten_by_the_background_auto_choice(self):
        two = SHARED["dir"] / "two_audio_b.mp4"
        if not two.exists():
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=s=320x180:r=25:d=40", "-f", "lavfi", "-i", "sine=f=300:d=40",
                            "-f", "lavfi", "-i", "sine=f=500:d=40", "-map", "0:v", "-map", "1:a", "-map", "2:a", "-t", "40", "-c:v", "libx264", "-preset", "ultrafast",
                            "-pix_fmt", "yuv420p", "-c:a", "aac", str(two)], check=True)
        self.app.pick_file = lambda *_: str(two)
        self.post("/api/source/file")
        self.post("/api/tracks", {"audio": [1], "video": []})            # the user picks A1 and unticks video immediately
        end = time.time() + 30
        while time.time() < end and self.state()["source"]["listening"]:
            time.sleep(0.2)
        self.assertEqual(self.state()["selection"], {"audio": [1], "video": []})


if __name__ == "__main__":
    unittest.main()

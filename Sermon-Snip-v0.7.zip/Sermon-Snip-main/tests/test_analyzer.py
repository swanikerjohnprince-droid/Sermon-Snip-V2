import math
import sys
import tempfile
import types
import unittest
import wave
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from analyzer import GpuError, analyze_wav_energy, candidates, transcribe


class StreamingWavAnalysisTests(unittest.TestCase):
    def make_wav(self, path, channels=1, rate=8000, duration=10.5):
        frames = int(rate * duration)
        with wave.open(str(path), "wb") as wf:
            wf.setnchannels(channels)
            wf.setsampwidth(2)
            wf.setframerate(rate)
            data = bytearray()
            for i in range(frames):
                # A non-silent, low-amplitude 220 Hz tone.
                sample = int(4000 * math.sin(2 * math.pi * 220 * i / rate))
                for _ in range(channels):
                    data.extend(sample.to_bytes(2, "little", signed=True))
            wf.writeframes(data)

    def test_longer_than_one_chunk_returns_per_second_scores(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "long_mono.wav"
            self.make_wav(path)
            duration, scores = analyze_wav_energy(path)
            self.assertAlmostEqual(duration, 10.5, places=2)
            self.assertEqual(len(scores), 11)
            self.assertTrue(all(0.0 <= score <= 1.0 for score in scores))
            self.assertTrue(any(score > 0 for score in scores))

    def test_stereo_wav_is_downmixed_without_full_audio_buffer(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "stereo.wav"
            self.make_wav(path, channels=2, duration=2.25)
            duration, scores = analyze_wav_energy(path)
            self.assertAlmostEqual(duration, 2.25, places=2)
            self.assertEqual(len(scores), 3)
            self.assertTrue(any(score > 0 for score in scores))


class HighlightCandidateTests(unittest.TestCase):
    def test_candidates_include_complete_thought_metadata_and_sort_by_score(self):
        transcript = [
            {"start": 0.0, "end": 18.0, "text": "The Bible says we must keep our faith because God is faithful."},
            {"start": 18.2, "end": 37.0, "text": "Listen to me, the promise of God is greater than your problem."},
            {"start": 37.2, "end": 58.0, "text": "Do not give up, because victory comes through faith in Jesus Christ."},
            {"start": 58.2, "end": 75.0, "text": "Today we remember that the kingdom of God will never fail."},
            {"start": 75.2, "end": 95.0, "text": "So keep trusting the Lord, and let your life show his glory."},
        ]
        energy = [0.4 + (i % 4) * 0.1 for i in range(100)]
        results = candidates(transcript, energy, 100, limit=20)
        self.assertTrue(results)
        scores = [item["score"] for item in results]
        self.assertEqual(scores, sorted(scores, reverse=True))
        self.assertTrue(all("complete_thought" in item for item in results))
        self.assertTrue(all(item["duration"] > 0 for item in results))
        self.assertTrue(all(item["text"].strip() for item in results))


class CandidateRegressionTests(unittest.TestCase):
    def test_results_never_overlap(self):
        # Previously the 'near-duplicate' clause let overlapping near-copies of a clip through.
        transcript = [{"start": i * 8.0, "end": i * 8.0 + 7.5,
                       "text": "Listen to me, the promise of God is victory, and faith never fails!"} for i in range(30)]
        results = candidates(transcript, [0.6] * 240, 240, limit=30)
        self.assertGreaterEqual(len(results), 3)
        for i, a in enumerate(results):
            for b in results[i + 1:]:
                self.assertFalse(a["start"] < b["end"] and b["start"] < a["end"], (a["start"], a["end"], b["start"], b["end"]))


class FakeSeg:
    def __init__(self, start, end, text):
        self.start, self.end, self.text = start, end, text


def install_fake_whisper(model_factory):
    sys.modules["faster_whisper"] = types.SimpleNamespace(WhisperModel=model_factory)


class TranscribeTests(unittest.TestCase):
    def tearDown(self):
        sys.modules.pop("faster_whisper", None)

    def make_wav(self, rate, seconds=40):
        import numpy as np
        path = Path(tempfile.mkdtemp()) / f"t{rate}.wav"
        with wave.open(str(path), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(rate)
            wf.writeframes((np.random.default_rng(0).uniform(-.2, .2, rate * seconds) * 32767).astype("<i2").tobytes())
        return path

    def test_audio_is_resampled_to_16khz_whatever_the_wav_rate(self):
        # Whisper treats raw arrays as 16 kHz; 44.1/48 kHz samples used to be passed through unconverted.
        for rate in (16000, 44100, 48000):
            seen = []

            class Model:
                def __init__(self, *a, **k): pass

                def transcribe(self, audio, **opts):
                    seen.append(len(audio))
                    return [FakeSeg(0.0, 5.0, "Words here.")], types.SimpleNamespace(language="en")

            install_fake_whisper(Model)
            transcribe(self.make_wav(rate), "x", device="cpu", language="en", chunk_seconds=30, overlap_seconds=2)
            self.assertEqual(max(seen), 16000 * 30, f"{rate} Hz wav gave {max(seen)} samples")

    def test_gpu_init_failure_raises_gpuerror_and_never_falls_back_to_cpu(self):
        devices = []

        class Model:
            def __init__(self, name, device, compute_type):
                devices.append(device)
                raise RuntimeError("Library cublas64_12.dll is not found or cannot be loaded")

        install_fake_whisper(Model)
        with self.assertRaises(GpuError) as ctx:
            transcribe(self.make_wav(16000, 5), "x", device="cuda")
        self.assertEqual(set(devices), {"cuda"})                 # CPU was never tried
        self.assertIn("cublas64_12.dll", str(ctx.exception))
        self.assertIn("RESULT", ctx.exception.diagnosis)         # includes the readable diagnosis

    def test_lazy_cuda_failure_during_decode_is_a_gpuerror(self):
        class Model:
            def __init__(self, *a, **k): pass

            def transcribe(self, audio, **opts):
                def gen():
                    raise RuntimeError("Could not locate cudnn_ops64_9.dll")
                    yield
                return gen(), types.SimpleNamespace(language="en")

        install_fake_whisper(Model)
        with self.assertRaises(GpuError):
            transcribe(self.make_wav(16000, 5), "x", device="cuda")

    def test_cpu_device_uses_cpu_only(self):
        devices = []

        class Model:
            def __init__(self, name, device, compute_type):
                devices.append((device, compute_type))

            def transcribe(self, audio, **opts):
                return [FakeSeg(0.0, 3.0, "Hello there.")], types.SimpleNamespace(language="en")

        install_fake_whisper(Model)
        rows, _ = transcribe(self.make_wav(16000, 5), "x", device="cpu")
        self.assertEqual(devices, [("cpu", "int8")])
        self.assertEqual(rows[0]["text"], "Hello there.")


if __name__ == "__main__":
    unittest.main()

"""verthor / AutoSubs wrappers, the shorts pipeline and the Resolve import script, against fake tools."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import autosubs_cli  # noqa: E402
import media  # noqa: E402
import pipeline  # noqa: E402
import reframe  # noqa: E402
import tools  # noqa: E402

FAKE_VERTHOR = [sys.executable, str(HERE / "fakes" / "fake_verthor.py")]
FAKE_AUTOSUBS = [sys.executable, str(HERE / "fakes" / "fake_autosubs.py")]
HAVE_FFMPEG = media.ffmpeg_available()
TRANSCRIPT = [{"start": 10.0, "end": 14.0, "text": "Listen to me, God is able to do a miracle."},
              {"start": 14.2, "end": 18.0, "text": "Do not give up, victory is coming."}]
HIGHLIGHT = {"start": 10.0, "end": 18.0, "title": "Listen to me God is able", "score": 88.0, "text": "..."}


_SHARED = {}


def setUpModule():
    if HAVE_FFMPEG:
        _SHARED["dir"] = Path(tempfile.mkdtemp())
        _SHARED["video"] = _SHARED["dir"] / "shared.mp4"
        make_video(_SHARED["video"], 20)


def tearDownModule():
    shutil.rmtree(_SHARED.get("dir", "."), ignore_errors=True) if _SHARED else None


def make_video(path, seconds=20):
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"testsrc2=s=640x360:r=25:d={seconds}",
                    "-f", "lavfi", "-i", f"sine=f=220:d={seconds}", "-c:v", "libx264", "-pix_fmt", "yuv420p",
                    "-c:a", "aac", "-shortest", str(path)], check=True)


class EnvMixin:
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self._saved = {k: os.environ.get(k) for k in ("FAKE_FAIL", "FAKE_MODE", "FAKE_SLOW", "FAKE_ARGS_LOG")}
        self._handoff = tools.HANDOFF_DIR
        pipeline.HANDOFF_DIR = self.tmp / "handoff"          # never write into the real home folder

    def tearDown(self):
        for k, v in self._saved.items():
            os.environ.pop(k, None) if v is None else os.environ.__setitem__(k, v)
        pipeline.HANDOFF_DIR = self._handoff
        shutil.rmtree(self.tmp, ignore_errors=True)


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg not installed")
class ReframeTests(EnvMixin, unittest.TestCase):
    def test_success_passes_the_exact_flags_verthor_expects(self):
        src = _SHARED["video"]
        os.environ["FAKE_ARGS_LOG"] = str(self.tmp / "args.txt")
        seen = []
        out = reframe.reframe_clip(FAKE_VERTHOR, src, 5.0, 11.5, self.tmp / "o" / "c.mp4", preset="sports",
                                   fast=True, progress=seen.append)
        args = (self.tmp / "args.txt").read_text()
        for expected in ("--preset sports", "--start 5.000", "--duration 6.500", "--video-encoder libx264", "--crf 18", "--fast"):
            self.assertIn(expected, args)
        self.assertTrue(out.exists())
        self.assertEqual(seen, [0.5, 1.0])                   # parsed from 'Processed 10/20' lines

    def test_failure_raises_with_tool_output(self):
        src = _SHARED["video"]
        os.environ["FAKE_FAIL"] = "1"
        with self.assertRaisesRegex(tools.ToolError, "could not open input"):
            reframe.reframe_clip(FAKE_VERTHOR, src, 0, 2, self.tmp / "c.mp4")

    def test_cancel_terminates_a_running_tool(self):
        src = _SHARED["video"]
        os.environ["FAKE_SLOW"] = "1"
        cancel = threading.Event()
        threading.Timer(1.5, cancel.set).start()
        with self.assertRaises(tools.Cancelled):
            reframe.reframe_clip(FAKE_VERTHOR, src, 0, 2, self.tmp / "c.mp4", cancel=cancel)

    def test_missing_executable_is_a_clear_error(self):
        with self.assertRaisesRegex(tools.ToolError, "not found"):
            reframe.reframe_clip(["definitely-not-installed-xyz"], "a", 0, 1, self.tmp / "c.mp4")


class AutoSubsTests(EnvMixin, unittest.TestCase):
    def test_caption_flags_and_output_file(self):
        os.environ["FAKE_ARGS_LOG"] = str(self.tmp / "args.txt")
        out = autosubs_cli.caption_srt(FAKE_AUTOSUBS, "clip.mp4", self.tmp / "c.srt", "small", "en")
        self.assertIn("AutoSubs caption", out.read_text())
        args = (self.tmp / "args.txt").read_text()
        for expected in ("-f srt", "-o", "-l en", "--density custom", "--max-lines 1", "--max-words-per-line 4"):
            self.assertIn(expected, args)

    def test_windows_style_silent_failure_is_reported_helpfully(self):
        os.environ["FAKE_MODE"] = "silent_fail"
        with self.assertRaisesRegex(tools.ToolError, "Windows its messages are hidden"):
            autosubs_cli.caption_srt(FAKE_AUTOSUBS, "clip.mp4", self.tmp / "c.srt")

    def test_error_message_from_stderr_is_surfaced(self):
        os.environ["FAKE_MODE"] = "error"
        with self.assertRaisesRegex(tools.ToolError, "model download blocked"):
            autosubs_cli.caption_srt(FAKE_AUTOSUBS, "clip.mp4", self.tmp / "c.srt")

    def test_exit_zero_without_output_file_is_still_a_failure(self):
        os.environ["FAKE_MODE"] = "noexit_nofile"
        with self.assertRaises(tools.ToolError):
            autosubs_cli.caption_srt(FAKE_AUTOSUBS, "clip.mp4", self.tmp / "c.srt")

    def test_transcript_parsing_prefers_original_segments_and_keeps_words(self):
        rows, lang = autosubs_cli.transcribe_autosubs(FAKE_AUTOSUBS, self.tmp / "a.wav", "small", "en")
        self.assertEqual(lang, "en")
        self.assertEqual([r["text"] for r in rows], ["Listen to me, God is able.", "Do not give up!"])
        self.assertEqual(rows[0]["words"][0]["word"], "Listen")

    def test_no_gpu_flag_is_passed_through(self):
        os.environ["FAKE_ARGS_LOG"] = str(self.tmp / "args.txt")
        autosubs_cli.transcribe_autosubs(FAKE_AUTOSUBS, self.tmp / "a.wav", extra=["--no-gpu"])
        self.assertIn("--no-gpu", (self.tmp / "args.txt").read_text())


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg not installed")
class PipelineTests(EnvMixin, unittest.TestCase):
    def setUp(self):
        super().setUp()
        self.src = _SHARED["video"]

    def run_pipeline(self, **kw):
        opts = pipeline.ShortsOptions(**kw)
        return pipeline.build_shorts(self.src, [HIGHLIGHT], TRANSCRIPT, self.tmp / "out", opts)

    def test_full_path_verthor_and_autosubs(self):
        m = self.run_pipeline(verthor_cmd=FAKE_VERTHOR, autosubs_cmd=FAKE_AUTOSUBS)
        clip = m["clips"][0]
        self.assertEqual((clip["reframe"], clip["caption_engine"], clip["warnings"]), ("verthor", "autosubs", []))
        self.assertEqual((clip["width"], clip["height"]), (1080, 1920))
        self.assertAlmostEqual(clip["duration"], 8.0, delta=0.4)
        out = self.tmp / "out"
        self.assertTrue((out / clip["file"]).exists() and (out / clip["captions"]).exists())
        self.assertEqual(json.loads((out / "manifest.json").read_text())["clips"][0]["file"], clip["file"])
        self.assertEqual((self.tmp / "handoff" / "last_manifest.txt").read_text(), str((out / "manifest.json").resolve()))

    def test_verthor_failure_falls_back_to_centre_crop_and_says_so(self):
        os.environ["FAKE_FAIL"] = "1"
        clip = self.run_pipeline(verthor_cmd=FAKE_VERTHOR, autosubs_cmd=FAKE_AUTOSUBS)["clips"][0]
        self.assertEqual(clip["reframe"], "center-crop")
        self.assertEqual((clip["width"], clip["height"]), (1080, 1920))
        self.assertTrue(any("verthor failed" in w for w in clip["warnings"]))

    def test_missing_tools_fall_back_with_builtin_captions(self):
        clip = self.run_pipeline()["clips"][0]
        self.assertEqual((clip["reframe"], clip["caption_engine"]), ("center-crop", "builtin"))
        srt = (self.tmp / "out" / clip["captions"]).read_text()
        self.assertIn("00:00:00,000 -->", srt)               # shifted so the clip starts at 0
        self.assertEqual(len(clip["warnings"]), 2)

    def test_autosubs_failure_falls_back_to_builtin(self):
        os.environ["FAKE_MODE"] = "silent_fail"
        clip = self.run_pipeline(verthor_cmd=FAKE_VERTHOR, autosubs_cmd=FAKE_AUTOSUBS)["clips"][0]
        self.assertEqual(clip["caption_engine"], "builtin")
        self.assertTrue(any("AutoSubs failed" in w for w in clip["warnings"]))

    def test_captions_none_and_burn_in(self):
        clip = self.run_pipeline(captions="none")["clips"][0]
        self.assertIsNone(clip["captions"])
        clip = self.run_pipeline(captions="builtin", burn_captions=True)["clips"][0]
        self.assertEqual(clip["warnings"], ["verthor not found, used centre crop"])

    def test_cancel_stops_before_next_clip(self):
        cancel = threading.Event(); cancel.set()
        with self.assertRaises(tools.Cancelled):
            pipeline.build_shorts(self.src, [HIGHLIGHT], TRANSCRIPT, self.tmp / "out", pipeline.ShortsOptions(), cancel=cancel)


if __name__ == "__main__":
    unittest.main()

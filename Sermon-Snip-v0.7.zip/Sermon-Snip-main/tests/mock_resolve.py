"""A mock of DaVinci Resolve's scripting API that reproduces the quirks documented by AutoSubs' authors:
 * timeline item frames are ABSOLUTE (timeline starts at 01:00:00:00 = frame 86400 at 24 fps)
 * AppendToTimeline fails the WHOLE batch (returns None) if any frame value is not an integer
 * AppendToTimeline returns truthy DEAD handles (GetStart() -> None) when the target track is locked
 * CreateEmptyTimeline returns None when the name is already used
"""


class Dead:
    def GetStart(self):
        return None


class MediaPoolItem:
    def __init__(self, path, fps=25.0):
        self.path, self.fps = path, fps

    def GetClipProperty(self, key):
        return {"File Path": self.path, "FPS": str(self.fps), "File Name": self.path.replace("\\", "/").split("/")[-1]}.get(key, "")


class Item:
    def __init__(self, name, mpi, start, end, left=0, track=None, kind="video"):
        self.name, self.mpi, self.start, self.end, self.left = name, mpi, start, end, left
        self.kind = kind

    def GetStart(self): return self.start
    def GetEnd(self): return self.end
    def GetName(self): return self.name
    def GetMediaPoolItem(self): return self.mpi
    def GetLeftOffset(self): return self.left


class Timeline:
    def __init__(self, name, fps=24.0, start_frame=86400, width=1920, height=1080):
        self.name, self.fps, self.start_frame, self.width, self.height = name, fps, start_frame, width, height
        self.tracks = {"video": [[]], "audio": [[]]}
        self.names = {}
        self.enabled = {}
        self.locked = set()
        self.settings = {}

    def GetName(self): return self.name
    def GetStartFrame(self): return self.start_frame
    def GetEndFrame(self): return max([it.end for t in self.tracks.values() for tr in t for it in tr] or [self.start_frame])
    def GetSetting(self, key):
        return {"timelineFrameRate": f"{self.fps:g}" + (" DF" if self.fps == 29.97 else ""), "timelineResolutionWidth": str(self.width),
                "timelineResolutionHeight": str(self.height)}.get(key, self.settings.get(key, ""))
    def SetSetting(self, key, value): self.settings[key] = value; return True
    def GetTrackCount(self, kind): return len(self.tracks[kind])
    def GetTrackName(self, kind, i): return self.names.get((kind, i), f"{kind[0].upper()}{i}")
    def GetIsTrackEnabled(self, kind, i): return self.enabled.get((kind, i), True)
    def GetItemListInTrack(self, kind, i): return list(self.tracks[kind][i - 1])
    def AddTrack(self, kind, sub=None): self.tracks[kind].append([]); return True


class Pool:
    def __init__(self, project):
        self.project = project
        self.folders = []
        self.imported = []

    def GetRootFolder(self): return "root"
    def AddSubFolder(self, parent, name): self.folders.append(name); return name
    def SetCurrentFolder(self, folder): return True

    def ImportMedia(self, paths):
        self.imported += list(paths)
        return [MediaPoolItem(p) for p in paths]

    def CreateEmptyTimeline(self, name):
        if any(t.name == name for t in self.project.timelines):
            return None
        t = Timeline(name, fps=self.project.timelines[0].fps)
        self.project.timelines.append(t)
        return t

    def AppendToTimeline(self, clips):
        tl = self.project.current
        placed = []
        clips = [c if isinstance(c, dict) else {"mediaPoolItem": c, "mediaType": 1, "startFrame": 0, "endFrame": 100, "trackIndex": 1}
                 for c in clips]                                 # Resolve also accepts plain media-pool items
        for c in clips:
            for key in ("startFrame", "endFrame", "recordFrame", "trackIndex"):
                if key in c and not isinstance(c[key], int):
                    return None                                  # Resolve 21: the whole batch is rejected
        for c in clips:
            kind = "video" if c["mediaType"] == 1 else "audio"
            idx = c.get("trackIndex", 1)
            if (kind, idx) in tl.locked:
                placed.append(Dead())
                continue
            rec = c.get("recordFrame", tl.start_frame)
            length = c["endFrame"] - c["startFrame"]
            item = Item(c["mediaPoolItem"].path.split("/")[-1], c["mediaPoolItem"], rec, rec + length, left=c["startFrame"], kind=kind)
            tl.tracks[kind][idx - 1].append(item)
            placed.append(item)
        return placed


class Project:
    def __init__(self, timelines):
        self.timelines = timelines
        self.current = timelines[0]
        self.pool = Pool(self)

    def GetName(self): return "Church"
    def GetMediaPool(self): return self.pool
    def GetCurrentTimeline(self): return self.current
    def SetCurrentTimeline(self, t): self.current = t; return True
    def GetTimelineCount(self): return len(self.timelines)
    def GetTimelineByIndex(self, n): return self.timelines[n - 1]


class Resolve:
    def __init__(self, project): self.project = project
    def GetVersionString(self): return "21.1 (mock)"
    def GetProjectManager(self):
        project = self.project
        return type("PM", (), {"GetCurrentProject": lambda s: project})()


def sunday_service(files="/media"):
    """A 40-second 24 fps timeline starting at 01:00:00:00: pastor mic on A2, music on A1, camera on V1 (two clips)."""
    tl = Timeline("Sunday Service")
    s = tl.start_frame
    cam_a, cam_b = MediaPoolItem(f"{files}/cam_a.mp4", 24.0), MediaPoolItem(f"{files}/cam_b.mp4", 24.0)
    mic, music = MediaPoolItem(f"{files}/mic.wav", 24.0), MediaPoolItem(f"{files}/music.wav", 24.0)
    tl.tracks["video"][0] = [Item("cam_a.mp4", cam_a, s, s + 20 * 24, left=0), Item("cam_b.mp4", cam_b, s + 20 * 24, s + 40 * 24, left=5 * 24)]
    tl.tracks["audio"] = [[Item("music.wav", music, s, s + 40 * 24, kind="audio")], [Item("mic.wav", mic, s, s + 40 * 24, left=2 * 24, kind="audio")]]
    tl.names[("audio", 1)], tl.names[("audio", 2)], tl.names[("video", 1)] = "Music", "Pastor mic", "Camera"
    project = Project([tl])
    return Resolve(project), project, tl

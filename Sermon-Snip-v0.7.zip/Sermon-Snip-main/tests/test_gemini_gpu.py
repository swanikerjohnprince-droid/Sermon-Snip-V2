"""Gemini re-ranking (against a mock of Google's API) and verthor GPU management (against fake interpreters)."""
import json
import os
import stat
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import gemini_rank as gr  # noqa: E402
import verthor_gpu as vg  # noqa: E402

MOMENTS = [{"id": 1, "start": 0, "end": 60, "text": "Welcome to church, please sign up for the offering."},
           {"id": 2, "start": 70, "end": 130, "text": "Listen to me. God is able. Don't give up, victory is coming!"},
           {"id": 3, "start": 140, "end": 200, "text": "Open your Bibles to page 40."}]


class FakeGoogle(BaseHTTPRequestHandler):
    mode = "ok"
    seen = []

    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.headers.get("x-goog-api-key") != "good-key":
            return self._send(400, {"error": {"message": "API key not valid. Please pass a valid API key."}})
        self._send(200, {"models": [{"name": "models/gemini-flash-latest", "supportedGenerationMethods": ["generateContent"]},
                                    {"name": "models/embedding-001", "supportedGenerationMethods": ["embedContent"]}]})

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        FakeGoogle.seen.append((self.path, self.headers.get("x-goog-api-key"), body))
        if self.headers.get("x-goog-api-key") != "good-key":
            return self._send(403, {"error": {"message": "API key not valid"}})
        if FakeGoogle.mode == "429":
            return self._send(429, {"error": {"message": "Resource exhausted"}})
        if FakeGoogle.mode == "blocked":
            return self._send(200, {"promptFeedback": {"blockReason": "SAFETY"}})
        if FakeGoogle.mode == "garbage":
            return self._send(200, {"candidates": [{"content": {"parts": [{"text": "not json at all"}]}}]})
        rows = [{"id": 1, "score": 5, "title": "Church announcements", "reason": "Housekeeping."},
                {"id": 2, "score": 96, "title": "God is able. Don't give up", "reason": "Strong hook and a complete thought."},
                {"id": 3, "score": 12, "title": "Open your Bibles", "reason": "Depends on context."},
                {"id": 99, "score": 100, "title": "invented", "reason": "not a real candidate"}]
        if FakeGoogle.mode == "outofrange":
            rows[1]["score"] = 250
        self._send(200, {"candidates": [{"content": {"parts": [{"text": json.dumps(rows)}]}}]})


class GeminiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), FakeGoogle)
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()
        cls.url = f"http://127.0.0.1:{cls.httpd.server_address[1]}/v1beta"

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()

    def setUp(self):
        FakeGoogle.mode, FakeGoogle.seen = "ok", []

    def test_scores_titles_and_reasons_come_back_keyed_by_candidate(self):
        out = gr.rerank(MOMENTS, "good-key", "m", self.url)
        self.assertEqual(sorted(out), [1, 2, 3])                      # the invented id 99 is dropped
        self.assertEqual((out[2]["score"], out[2]["title"]), (96.0, "God is able. Don't give up"))
        self.assertIn("complete thought", out[2]["reason"])

    def test_request_is_structured_and_carries_only_transcript_text(self):
        gr.rerank(MOMENTS, "good-key", "gemini-test", self.url)
        path, key, body = FakeGoogle.seen[0]
        self.assertTrue(path.endswith("/models/gemini-test:generateContent"))
        self.assertEqual(key, "good-key")                              # sent as a header, never in the URL
        self.assertNotIn("good-key", path)
        cfg = body["generationConfig"]
        self.assertEqual(cfg["responseMimeType"], "application/json")
        self.assertIn("responseSchema", cfg)
        prompt = body["contents"][0]["parts"][0]["text"]
        self.assertIn("[id 2]", prompt)
        self.assertIn("Listen to me", prompt)

    def test_scores_are_clamped_to_0_100(self):
        FakeGoogle.mode = "outofrange"
        self.assertEqual(gr.rerank(MOMENTS, "good-key", "m", self.url)[2]["score"], 100.0)

    def test_bad_key_has_a_helpful_message(self):
        with self.assertRaisesRegex(gr.GeminiError, "rejected the API key"):
            gr.rerank(MOMENTS, "bad", "m", self.url)

    def test_rate_limit_message(self):
        FakeGoogle.mode = "429"
        with self.assertRaisesRegex(gr.GeminiError, "rate limit"):
            gr.rerank(MOMENTS, "good-key", "m", self.url)

    def test_blocked_and_garbage_answers_fail_cleanly(self):
        FakeGoogle.mode = "blocked"
        with self.assertRaisesRegex(gr.GeminiError, "blocked: SAFETY"):
            gr.rerank(MOMENTS, "good-key", "m", self.url)
        FakeGoogle.mode = "garbage"
        with self.assertRaisesRegex(gr.GeminiError, "no usable ranking"):
            gr.rerank(MOMENTS, "good-key", "m", self.url)

    def test_unreachable_server_is_reported_not_raised_raw(self):
        with self.assertRaisesRegex(gr.GeminiError, "Could not reach"):
            gr.rerank(MOMENTS, "good-key", "m", "http://127.0.0.1:1/v1beta", timeout=2)

    def test_key_test_lists_only_generation_models(self):
        self.assertEqual(gr.test_key("good-key", self.url), ["gemini-flash-latest"])
        with self.assertRaises(gr.GeminiError):
            gr.test_key("", self.url)

    def test_blend_weights_the_two_scores(self):
        self.assertEqual(gr.blend(40, 90, 0.7), 75.0)
        self.assertEqual(gr.blend(40, 90, 1.0), 90.0)

    def test_key_comes_from_environment_or_config_and_environment_wins(self):
        os.environ.pop("GEMINI_API_KEY", None)
        self.assertEqual(gr.get_key({"gemini_key": " abc "}), "abc")
        os.environ["GEMINI_API_KEY"] = "envkey"
        try:
            self.assertEqual(gr.get_key({"gemini_key": "abc"}), "envkey")
        finally:
            del os.environ["GEMINI_API_KEY"]

    def test_long_candidates_are_truncated_to_keep_prompts_small(self):
        self.assertLess(len(gr._clip_text("word " * 1000).split()), 200)


def fake_python(folder, body):
    folder.mkdir(parents=True, exist_ok=True)
    p = folder / "python"
    p.write_text("#!/bin/sh\n" + body)
    p.chmod(p.stat().st_mode | stat.S_IEXEC)
    return p


class VerthorGpuTests(unittest.TestCase):
    def setUp(self):
        self.d = Path(tempfile.mkdtemp())

    def verthor(self, python_body):
        fake_python(self.d / "Scripts", python_body)
        exe = self.d / "Scripts" / "verthor"
        exe.write_text("#!/bin/sh\n")
        return [str(exe)]

    def test_python_is_found_next_to_the_verthor_executable(self):
        cmd = self.verthor("echo hi")
        self.assertEqual(vg.verthor_python(cmd), [str(self.d / "Scripts" / "python")])
        self.assertEqual(vg.verthor_python([sys.executable, "-m", "verthor"]), [sys.executable])
        self.assertIsNone(vg.verthor_python(["/nowhere/verthor"]))

    def test_status_reports_cpu_only_torch(self):
        cmd = self.verthor('echo \'{"torch": "2.8.0", "cuda": false, "cuda_build": null, "device": null}\'')
        st = vg.gpu_status(cmd)
        self.assertEqual((st["torch"], st["cuda"]), ("2.8.0", False))

    def test_status_reports_the_gpu_name(self):
        cmd = self.verthor('echo \'{"torch": "2.8.0+cu128", "cuda": true, "cuda_build": "12.8", "device": "NVIDIA GeForce RTX 4050 Laptop GPU"}\'')
        st = vg.gpu_status(cmd)
        self.assertTrue(st["cuda"])
        self.assertIn("RTX 4050", st["device"])

    def test_noise_before_the_json_line_is_tolerated(self):
        cmd = self.verthor('echo "some warning"; echo \'{"torch": "2", "cuda": true, "device": "X"}\'')
        self.assertTrue(vg.gpu_status(cmd)["cuda"])

    def test_missing_or_broken_python_is_an_error_not_a_crash(self):
        self.assertIn("error", vg.gpu_status(["/nowhere/verthor"]))
        self.assertIn("error", vg.gpu_status(self.verthor("exit 3")))

    def test_wheel_folder_follows_the_drivers_cuda_version(self):
        self.assertEqual(vg.tag_for_driver((13, 0)), "cu130")
        self.assertEqual(vg.tag_for_driver((12, 9)), "cu128")
        self.assertEqual(vg.tag_for_driver((12, 8)), "cu128")
        self.assertEqual(vg.tag_for_driver((12, 6)), "cu126")
        self.assertIsNone(vg.tag_for_driver((12, 4)))                    # too old: refuse rather than install something that cannot run
        self.assertIsNone(vg.tag_for_driver(None))

    def test_install_uses_the_right_index_and_verifies_the_gpu(self):
        log = self.d / "args.txt"
        cmd = self.verthor(f'echo "$@" >> {log}; case "$*" in *-c*) echo \'{{"torch":"2.8.0+cu128","cuda":true,"device":"RTX"}}\';; esac')
        orig = vg.driver_cuda_version
        vg.driver_cuda_version = lambda: (12, 9)
        try:
            st = vg.install_cuda_torch(cmd)
        finally:
            vg.driver_cuda_version = orig
        self.assertTrue(st["cuda"])
        text = log.read_text()
        self.assertIn("--index-url https://download.pytorch.org/whl/cu128", text)
        self.assertIn("--force-reinstall", text)
        self.assertIn("torch torchvision", text)

    def test_install_refuses_when_the_driver_is_too_old(self):
        orig = vg.driver_cuda_version
        vg.driver_cuda_version = lambda: (11, 8)
        try:
            with self.assertRaisesRegex(RuntimeError, "Update the driver"):
                vg.install_cuda_torch(self.verthor("echo"))
        finally:
            vg.driver_cuda_version = orig

    def test_install_reports_when_torch_still_cannot_see_the_gpu(self):
        cmd = self.verthor('case "$*" in *-c*) echo \'{"torch":"2.8.0","cuda":false}\';; esac')
        orig = vg.driver_cuda_version
        vg.driver_cuda_version = lambda: (12, 8)
        try:
            with self.assertRaisesRegex(RuntimeError, "still cannot see the GPU"):
                vg.install_cuda_torch(cmd)
        finally:
            vg.driver_cuda_version = orig


if __name__ == "__main__":
    unittest.main()

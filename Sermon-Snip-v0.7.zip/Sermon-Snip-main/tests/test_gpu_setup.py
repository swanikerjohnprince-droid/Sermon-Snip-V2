"""GPU discovery/prepare logic, exercised against fake Windows folder layouts (runs on any OS)."""
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import gpu_setup  # noqa: E402


def touch(folder, *names):
    folder.mkdir(parents=True, exist_ok=True)
    for n in names:
        (folder / n).write_bytes(b"MZ")
    return folder


CUBLAS = gpu_setup.CUBLAS_DLLS
CUDNN = gpu_setup.CUDNN_CORE


class DiscoverTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.site = self.tmp / "site-packages"
        self.pf = self.tmp / "Program Files"

    def test_finds_pip_wheel_layout(self):
        touch(self.site / "nvidia" / "cublas" / "bin", *CUBLAS)
        touch(self.site / "nvidia" / "cudnn" / "bin", *CUDNN)
        found = gpu_setup.discover(roots=[self.site], env={"PATH": ""}, program_files=self.pf)
        self.assertEqual(found["cublas_dir"], self.site / "nvidia" / "cublas" / "bin")
        self.assertEqual(found["cudnn_dir"], self.site / "nvidia" / "cudnn" / "bin")
        self.assertEqual(found["cublas_source"], "pip wheel")

    def test_cuda13_only_toolkit_is_reported_as_wrong_version(self):
        # The classic trap: 'latest CUDA' installs 13.x, which has cublas64_13.dll but no cublas64_12.dll.
        touch(self.pf / "NVIDIA GPU Computing Toolkit" / "CUDA" / "v13.0" / "bin" / "x64", "cublas64_13.dll")
        found = gpu_setup.discover(roots=[], env={"PATH": ""}, program_files=self.pf)
        self.assertIsNone(found["cublas_dir"])
        self.assertTrue(found["toolkits"][0]["has_cublas13"])
        self.assertFalse(found["toolkits"][0]["has_cublas12"])

    def test_cuda12_toolkit_and_cudnn_installer_subfolder(self):
        touch(self.pf / "NVIDIA GPU Computing Toolkit" / "CUDA" / "v12.6" / "bin", *CUBLAS)
        touch(self.pf / "NVIDIA" / "CUDNN" / "v9.5" / "bin" / "12.6", *CUDNN)   # real cuDNN 9 installer layout
        found = gpu_setup.discover(roots=[], env={"PATH": ""}, program_files=self.pf)
        self.assertIn("v12.6", str(found["cublas_dir"]))
        self.assertIn("12.6", str(found["cudnn_dir"]))
        self.assertTrue(found["cudnn_source"].startswith("cuDNN installer"))

    def test_pip_wheel_beats_a_mismatched_system_install(self):
        touch(self.site / "nvidia" / "cudnn" / "bin", *CUDNN)
        touch(self.pf / "NVIDIA" / "CUDNN" / "v9.99" / "bin" / "12.9", *CUDNN)
        found = gpu_setup.discover(roots=[self.site], env={"PATH": ""}, program_files=self.pf)
        self.assertEqual(found["cudnn_source"], "pip wheel")

    def test_requires_both_cublas_files(self):
        touch(self.site / "nvidia" / "cublas" / "bin", "cublas64_12.dll")   # cublasLt missing
        found = gpu_setup.discover(roots=[self.site], env={"PATH": ""}, program_files=self.pf)
        self.assertIsNone(found["cublas_dir"])

    def test_path_entries_are_searched(self):
        d = touch(self.tmp / "custom", *CUBLAS)
        found = gpu_setup.discover(roots=[], env={"PATH": str(d)}, program_files=self.pf)
        self.assertEqual(found["cublas_dir"], d)
        self.assertEqual(found["cublas_source"], "PATH")


class PrepareTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.site = self.tmp / "site"
        self.cublas = touch(self.site / "nvidia" / "cublas" / "bin", *CUBLAS)
        self.cudnn = touch(self.site / "nvidia" / "cudnn" / "bin", *CUDNN)
        self.saved = {k: os.environ.get(k) for k in ("PATH", "CUDA_PATH")}
        gpu_setup._prepared = None

    def tearDown(self):
        for k, v in self.saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        gpu_setup._prepared = None

    def test_path_is_prepended_and_cuda_path_redirected(self):
        # User has CUDA 13 on PATH and CUDA_PATH pointing at it: ours must win, in-process only.
        os.environ["PATH"] = os.pathsep.join(["/opt/cuda13/bin", "/opt/other"])
        os.environ["CUDA_PATH"] = "/opt/cuda13"
        res = gpu_setup.prepare_cuda_environment(force=True, windows=True, roots=[self.site],
                                                 env=dict(os.environ), program_files=self.tmp / "none")
        parts = os.environ["PATH"].split(os.pathsep)
        self.assertEqual(parts[0], str(self.cublas))
        self.assertEqual(parts[1], str(self.cudnn))
        self.assertIn("/opt/cuda13/bin", parts)                      # not deleted, just demoted
        self.assertEqual(os.environ["CUDA_PATH"], str(self.cublas.parent))
        self.assertEqual(res.cuda_path_before, "/opt/cuda13")

    def test_no_duplicate_path_entries(self):
        os.environ["PATH"] = os.pathsep.join([str(self.cublas).upper(), "/opt/other"])
        gpu_setup.prepare_cuda_environment(force=True, windows=True, roots=[self.site],
                                           env=dict(os.environ), program_files=self.tmp / "none")
        lowered = [p.lower() for p in os.environ["PATH"].split(os.pathsep)]
        self.assertEqual(lowered.count(str(self.cublas).lower()), 1)

    def test_nothing_found_leaves_environment_alone(self):
        before = os.environ["PATH"]
        gpu_setup.prepare_cuda_environment(force=True, windows=True, roots=[], env={"PATH": ""},
                                           program_files=self.tmp / "none")
        self.assertEqual(os.environ["PATH"], before)

    def test_non_windows_is_a_noop(self):
        before = os.environ["PATH"]
        res = gpu_setup.prepare_cuda_environment(force=True, windows=False)
        self.assertEqual(os.environ["PATH"], before)
        self.assertEqual(res.preload, [])


class ReportTests(unittest.TestCase):
    def test_warn_does_not_block_but_fail_does(self):
        r = gpu_setup.Report()
        r.add("a", "ok", "x")
        r.add("b", "warn", "y", "fix")
        self.assertTrue(r.ready)
        r.add("c", "fail", "z", "fix it")
        self.assertFalse(r.ready)
        self.assertIn("-> fix it", r.text())
        self.assertIn("NOT ready", r.text())


if __name__ == "__main__":
    unittest.main()

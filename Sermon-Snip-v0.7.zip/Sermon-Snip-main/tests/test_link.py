"""ResolveLink + the generated in-Resolve scripts, executed against the mock Resolve."""
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
import mock_resolve as mr  # noqa: E402
import resolve_link as rl  # noqa: E402


def run_resolve_script(name, resolve, home):
    """Execute a generated script the way Resolve does: one file, `resolve` as a global."""
    old = os.environ.get("HOME")
    os.environ["HOME"] = str(home)
    try:
        src = rl.build_script(name)
        ns = {"resolve": resolve, "__name__": "__main__"}
        exec(compile(src, name, "exec"), ns)            # noqa: S102
        return ns
    finally:
        os.environ["HOME"] = old if old is not None else ""


class ScriptTests(unittest.TestCase):
    def setUp(self):
        self.home = Path(tempfile.mkdtemp())
        self.handoff = self.home / "SermonSnip"
        self.resolve, self.project, self.tl = mr.sunday_service()
        self.link = rl.ResolveLink(handoff=self.handoff)

    def tearDown(self):
        shutil.rmtree(self.home, ignore_errors=True)

    def run_script(self):
        return run_resolve_script("SermonSnip.py", self.resolve, self.home)

    def test_there_is_exactly_one_script_to_run(self):
        self.assertEqual(list(rl.GENERATED), ["SermonSnip.py"])
        src = rl.build_script("SermonSnip.py")
        compile(src, "SermonSnip.py", "exec")
        self.assertNotIn("import resolve_bridge", src)                  # self-contained: nothing to import inside Resolve

    def test_first_run_with_nothing_pending_sends_the_timeline(self):
        self.run_script()
        snap = self.link.read_snapshot()
        self.assertEqual(snap["timeline"], "Sunday Service")
        self.assertEqual([t["name"] for t in snap["tracks"] if t["type"] == "audio"], ["Music", "Pastor mic"])
        self.assertIsNotNone(self.link.snapshot_mtime())

    def test_no_snapshot_yet_is_none_not_an_error(self):
        self.assertIsNone(self.link.read_snapshot())

    def cut_job(self):
        return {"timeline": "Sunday Service", "bin": "Moments", "moments": [{"name": "01 Test", "placements": [
            {"type": "video", "track": 1, "item": 0, "src_start": 2.0, "src_end": 8.0, "rec": 0.0}]}]}

    def test_pending_cut_is_applied_and_the_sermon_snapshot_is_not_overwritten(self):
        self.run_script()                                               # capture
        before = self.link.snapshot_path.read_text()
        job_id, immediate = self.link.submit_cut(self.cut_job())
        self.assertIsNone(immediate)
        self.assertIsNone(self.link.read_cut_result(job_id))
        self.run_script()                                               # the same single script now does the cutting
        result = self.link.read_cut_result(job_id)
        self.assertEqual(result["created"], [{"name": "01 Test", "clips": 1}])
        self.assertEqual(self.project.timelines[1].name, "01 Test")
        self.assertEqual(self.project.current.name, "Sunday Service")  # the user is put back on their sermon timeline
        self.assertEqual(self.link.snapshot_path.read_text(), before)  # and the app's snapshot still describes the sermon

    def test_a_finished_job_is_not_applied_twice(self):
        self.link.submit_cut(self.cut_job())
        self.run_script()
        self.run_script()
        self.assertEqual(len(self.project.timelines), 2)                # one new timeline, not two
        self.assertIsNotNone(self.link.snapshot_mtime())                # the second run found nothing pending and captured instead

    def test_stale_result_from_an_older_job_is_ignored(self):
        self.handoff.mkdir(parents=True)
        (self.handoff / rl.CUT_RESULT_NAME).write_text(json.dumps({"job_id": "old", "created": [], "problems": []}))
        self.assertIsNone(self.link.read_cut_result("new"))

    def test_submitting_a_new_job_clears_the_previous_result(self):
        self.handoff.mkdir(parents=True)
        (self.handoff / rl.CUT_RESULT_NAME).write_text("{}")
        self.link.submit_cut({"moments": []})
        self.assertFalse((self.handoff / rl.CUT_RESULT_NAME).exists())

    def test_pending_import_is_run_by_the_same_script(self):
        d = self.home / "pkg"
        d.mkdir()
        (d / "01_a.mp4").write_bytes(b"x")
        (d / "manifest.json").write_text(json.dumps({"clips": [{"index": 1, "file": "01_a.mp4", "title": "Hi", "width": 1080, "height": 1920, "fps": 25}]}))
        self.assertIsNone(self.link.import_package(d / "manifest.json"))
        self.assertTrue((self.handoff / "import_pending.json").exists())
        self.run_script()
        self.assertEqual(self.project.timelines[-1].settings["timelineResolutionHeight"], "1920")
        self.assertEqual(self.link.read_import_result()["imported"], 1)
        self.assertFalse((self.handoff / "import_pending.json").exists())

    def test_install_scripts_writes_the_script_and_the_diagnostic(self):
        dest, written = rl.install_scripts(self.home / "Utility")
        self.assertEqual(sorted(written), ["SermonSnip.py", "SermonSnip_Diagnose.py"])
        for name in written:
            compile((dest / name).read_text(), name, "exec")


class DirectConnectionTests(unittest.TestCase):
    def test_direct_mode_calls_the_bridge_without_files(self):
        resolve, project, tl = mr.sunday_service()
        link = rl.ResolveLink(handoff=tempfile.mkdtemp(), external_loader=lambda: (resolve, "ok"))
        self.assertTrue(link.connect_direct())
        self.assertEqual(link.read_snapshot()["timeline"], "Sunday Service")
        job_id, report = link.submit_cut({"timeline": "Sunday Service", "moments": [{"name": "A", "placements": [
            {"type": "video", "track": 1, "item": 0, "src_start": 0.0, "src_end": 3.0, "rec": 0.0}]}]})
        self.assertEqual(report["created"], [{"name": "A", "clips": 1}])

    def test_failed_connection_reports_why_and_stays_in_script_mode(self):
        link = rl.ResolveLink(handoff=tempfile.mkdtemp(), external_loader=lambda: (None, "Studio required"))
        self.assertFalse(link.connect_direct())
        self.assertFalse(link.direct)
        self.assertEqual(link.reason, "Studio required")

    def test_external_loader_with_a_fake_scripting_module(self):
        api = Path(tempfile.mkdtemp())
        (api / "Modules").mkdir()
        (api / "Modules" / "DaVinciResolveScript.py").write_text(
            "class R:\n    def GetVersionString(self): return '20.1'\n"
            "def scriptapp(name): return R() if name == 'Resolve' else None\n")
        os.environ["SERMONSNIP_RESOLVE_API"] = str(api)
        try:
            resolve, reason = rl.load_resolve_external()
        finally:
            del os.environ["SERMONSNIP_RESOLVE_API"]
            sys.modules.pop("DaVinciResolveScript", None)
        self.assertIsNotNone(resolve)
        self.assertIn("20.1", reason)

    def test_missing_resolve_installation_is_explained(self):
        os.environ["SERMONSNIP_RESOLVE_API"] = "/definitely/not/here"
        try:
            resolve, reason = rl.load_resolve_external()
        finally:
            del os.environ["SERMONSNIP_RESOLVE_API"]
        self.assertIsNone(resolve)
        self.assertIn("not found", reason)


if __name__ == "__main__":
    unittest.main()
